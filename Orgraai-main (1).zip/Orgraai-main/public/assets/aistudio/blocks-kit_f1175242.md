# Building Blocks Kit

Add these to `src/components/blocks/`. They use the same tokens and base components from the template kit, so they restyle automatically when the palette and fonts change.

Each block takes content as props. The generator writes real copy and picks which blocks to use. It does not write styles.

---

## 1. `HeroCentered.tsx`

Big headline, centered, with a soft accent glow. Good for SaaS, tools, startups.

```tsx
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/Reveal";

type Cta = { label: string; href: string };

export function HeroCentered({
  eyebrow,
  title,
  description,
  primary,
  secondary,
}: {
  eyebrow?: string;
  title: string;
  description: string;
  primary: Cta;
  secondary?: Cta;
}) {
  return (
    <section className="relative overflow-hidden py-20 md:py-36">
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-0 h-[28rem] w-[44rem] -translate-x-1/2 rounded-full bg-accent/20 blur-3xl"
      />
      <div className="container relative text-center">
        <Reveal>
          {eyebrow && (
            <span className="mb-6 inline-block rounded-full border border-border bg-card px-4 py-1.5 text-sm font-medium text-muted-foreground shadow-soft">
              {eyebrow}
            </span>
          )}
          <h1 className="mx-auto max-w-4xl text-4xl font-bold leading-[1.05] md:text-7xl">
            {title}
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl">
            {description}
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Button size="lg" onClick={() => (window.location.href = primary.href)}>
              {primary.label}
            </Button>
            {secondary && (
              <Button
                size="lg"
                variant="outline"
                onClick={() => (window.location.href = secondary.href)}
              >
                {secondary.label}
              </Button>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
```

---

## 2. `HeroSplit.tsx`

Text on the left, image or visual on the right, with a slightly rotated frame. Good for products, services, portfolios.

```tsx
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/Reveal";

export function HeroSplit({
  eyebrow,
  title,
  description,
  primary,
  secondary,
  imageUrl,
  imageAlt,
  badge,
}: {
  eyebrow?: string;
  title: string;
  description: string;
  primary: { label: string; href: string };
  secondary?: { label: string; href: string };
  imageUrl: string;
  imageAlt: string;
  badge?: { value: string; label: string };
}) {
  return (
    <section className="py-16 md:py-28">
      <div className="container grid items-center gap-12 md:grid-cols-2">
        <Reveal>
          {eyebrow && (
            <p className="mb-4 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
              {eyebrow}
            </p>
          )}
          <h1 className="text-4xl font-bold leading-[1.05] md:text-6xl">{title}</h1>
          <p className="mt-6 max-w-lg text-lg text-muted-foreground">{description}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" onClick={() => (window.location.href = primary.href)}>
              {primary.label}
            </Button>
            {secondary && (
              <Button
                size="lg"
                variant="outline"
                onClick={() => (window.location.href = secondary.href)}
              >
                {secondary.label}
              </Button>
            )}
          </div>
        </Reveal>

        <Reveal delay={0.1} className="relative">
          <div className="absolute -inset-3 rotate-2 rounded-lg bg-accent/30" aria-hidden />
          <img
            src={imageUrl}
            alt={imageAlt}
            className="relative aspect-[4/5] w-full rounded-lg object-cover shadow-lift md:aspect-square"
            loading="eager"
          />
          {badge && (
            <div className="absolute -bottom-5 left-4 rounded-lg border border-border bg-card px-5 py-3 shadow-lift md:-left-6">
              <p className="font-heading text-2xl font-bold">{badge.value}</p>
              <p className="text-sm text-muted-foreground">{badge.label}</p>
            </div>
          )}
        </Reveal>
      </div>
    </section>
  );
}
```

---

## 3. `Features.tsx` (bento grid, not the same 3 cards)

First feature is large, the rest fill the grid. Avoids the identical icon-card look.

```tsx
import type { LucideIcon } from "lucide-react";
import { Section, SectionHeading } from "@/components/Section";
import { Reveal } from "@/components/Reveal";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type Feature = { icon: LucideIcon; title: string; text: string };

export function Features({
  id,
  eyebrow,
  title,
  description,
  items,
}: {
  id?: string;
  eyebrow?: string;
  title: string;
  description?: string;
  items: Feature[]; // 4 to 6 items works best
}) {
  return (
    <Section id={id}>
      <SectionHeading eyebrow={eyebrow} title={title} description={description} />
      <div className="grid gap-4 md:grid-cols-3 md:gap-6">
        {items.map((f, i) => {
          const Icon = f.icon;
          const featured = i === 0;
          return (
            <Reveal
              key={f.title}
              delay={i * 0.06}
              className={cn(featured && "md:col-span-2 md:row-span-2")}
            >
              <Card
                hoverable
                className={cn(
                  "h-full",
                  featured && "bg-primary text-primary-foreground"
                )}
              >
                <CardContent className={cn(featured && "flex h-full flex-col justify-end md:p-10")}>
                  <div
                    className={cn(
                      "mb-5 flex h-11 w-11 items-center justify-center rounded-md",
                      featured ? "bg-accent text-accent-foreground" : "bg-muted text-foreground"
                    )}
                  >
                    <Icon className="h-5 w-5" aria-hidden />
                  </div>
                  <h3 className={cn("font-semibold", featured ? "text-3xl" : "text-xl")}>
                    {f.title}
                  </h3>
                  <p
                    className={cn(
                      "mt-2",
                      featured ? "max-w-md text-primary-foreground/80" : "text-muted-foreground"
                    )}
                  >
                    {f.text}
                  </p>
                </CardContent>
              </Card>
            </Reveal>
          );
        })}
      </div>
    </Section>
  );
}
```

---

## 4. `FeatureSplit.tsx` (alternating image and text rows)

```tsx
import { Check } from "lucide-react";
import { Section } from "@/components/Section";
import { Reveal } from "@/components/Reveal";
import { cn } from "@/lib/utils";

type Row = {
  eyebrow?: string;
  title: string;
  text: string;
  bullets?: string[];
  imageUrl: string;
  imageAlt: string;
};

export function FeatureSplit({ id, rows }: { id?: string; rows: Row[] }) {
  return (
    <Section id={id} className="space-y-20 md:space-y-32">
      {rows.map((r, i) => (
        <div key={r.title} className="grid items-center gap-10 md:grid-cols-2 md:gap-16">
          <Reveal className={cn(i % 2 === 1 && "md:order-2")}>
            <img
              src={r.imageUrl}
              alt={r.imageAlt}
              className="aspect-[4/3] w-full rounded-lg object-cover shadow-lift"
              loading="lazy"
            />
          </Reveal>
          <Reveal delay={0.08}>
            {r.eyebrow && (
              <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                {r.eyebrow}
              </p>
            )}
            <h3 className="text-3xl font-semibold md:text-4xl">{r.title}</h3>
            <p className="mt-4 text-lg text-muted-foreground">{r.text}</p>
            {r.bullets && (
              <ul className="mt-6 space-y-3">
                {r.bullets.map((b) => (
                  <li key={b} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                      <Check className="h-3.5 w-3.5" aria-hidden />
                    </span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            )}
          </Reveal>
        </div>
      ))}
    </Section>
  );
}
```

---

## 5. `Stats.tsx`

```tsx
import { Section } from "@/components/Section";
import { Reveal } from "@/components/Reveal";

export function Stats({ items }: { items: { value: string; label: string }[] }) {
  return (
    <Section className="py-12 md:py-16">
      <div className="grid grid-cols-2 gap-8 rounded-lg border border-border bg-card p-8 shadow-soft md:grid-cols-4 md:p-12">
        {items.map((s, i) => (
          <Reveal key={s.label} delay={i * 0.06}>
            <p className="font-heading text-4xl font-bold text-primary md:text-5xl">
              {s.value}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{s.label}</p>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
```

---

## 6. `Testimonials.tsx`

```tsx
import { Quote } from "lucide-react";
import { Section, SectionHeading } from "@/components/Section";
import { Reveal } from "@/components/Reveal";
import { Card, CardContent } from "@/components/ui/card";

type Testimonial = {
  quote: string;
  name: string;
  role: string;
  avatarUrl?: string;
};

export function Testimonials({
  id,
  title,
  description,
  items,
}: {
  id?: string;
  title: string;
  description?: string;
  items: Testimonial[]; // 3 items
}) {
  return (
    <Section id={id} className="bg-muted/50">
      <SectionHeading eyebrow="Reviews" title={title} description={description} />
      <div className="grid gap-6 md:grid-cols-3">
        {items.map((t, i) => (
          <Reveal key={t.name} delay={i * 0.08}>
            <Card className="h-full">
              <CardContent className="flex h-full flex-col">
                <Quote className="mb-4 h-7 w-7 text-accent" aria-hidden />
                <p className="flex-1 text-lg leading-relaxed">{t.quote}</p>
                <div className="mt-6 flex items-center gap-3 border-t border-border pt-5">
                  {t.avatarUrl ? (
                    <img
                      src={t.avatarUrl}
                      alt={t.name}
                      className="h-11 w-11 rounded-full object-cover"
                      loading="lazy"
                    />
                  ) : (
                    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary font-semibold text-primary-foreground">
                      {t.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <p className="font-medium">{t.name}</p>
                    <p className="text-sm text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
```

---

## 7. `Pricing.tsx`

```tsx
import { Check } from "lucide-react";
import { Section, SectionHeading } from "@/components/Section";
import { Reveal } from "@/components/Reveal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type Plan = {
  name: string;
  price: string;
  period?: string;
  description: string;
  features: string[];
  cta: string;
  href: string;
  highlighted?: boolean;
};

export function Pricing({
  id,
  title,
  description,
  plans,
}: {
  id?: string;
  title: string;
  description?: string;
  plans: Plan[]; // 2 or 3 plans
}) {
  return (
    <Section id={id}>
      <SectionHeading eyebrow="Pricing" title={title} description={description} />
      <div className="grid items-stretch gap-6 md:grid-cols-3">
        {plans.map((p, i) => (
          <Reveal key={p.name} delay={i * 0.08}>
            <Card
              className={cn(
                "relative h-full",
                p.highlighted && "border-primary ring-2 ring-primary md:-translate-y-3"
              )}
            >
              {p.highlighted && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
                  Most popular
                </span>
              )}
              <CardContent className="flex h-full flex-col">
                <h3 className="text-xl font-semibold">{p.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{p.description}</p>
                <p className="mt-6">
                  <span className="font-heading text-5xl font-bold">{p.price}</span>
                  {p.period && (
                    <span className="ml-1 text-muted-foreground">{p.period}</span>
                  )}
                </p>
                <ul className="my-8 flex-1 space-y-3">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 text-sm">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button
                  size="lg"
                  variant={p.highlighted ? "primary" : "outline"}
                  className="w-full"
                  onClick={() => (window.location.href = p.href)}
                >
                  {p.cta}
                </Button>
              </CardContent>
            </Card>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
```

---

## 8. `FAQ.tsx` (animated accordion)

```tsx
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";
import { Section, SectionHeading } from "@/components/Section";

export function FAQ({
  id,
  title,
  items,
}: {
  id?: string;
  title: string;
  items: { q: string; a: string }[];
}) {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <Section id={id} className="bg-muted/50">
      <div className="mx-auto max-w-3xl">
        <SectionHeading eyebrow="FAQ" title={title} />
        <div className="divide-y divide-border rounded-lg border border-border bg-card shadow-soft">
          {items.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q}>
                <button
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-medium hover:bg-muted/50"
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                >
                  {item.q}
                  <Plus
                    className={`h-5 w-5 shrink-0 transition-transform duration-200 ${
                      isOpen ? "rotate-45" : ""
                    }`}
                    aria-hidden
                  />
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <p className="px-6 pb-6 text-muted-foreground">{item.a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}
```

---

## 9. `CTABanner.tsx`

```tsx
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/Reveal";

export function CTABanner({
  title,
  description,
  cta,
  href,
}: {
  title: string;
  description: string;
  cta: string;
  href: string;
}) {
  return (
    <section className="py-16 md:py-28">
      <div className="container">
        <Reveal>
          <div className="relative overflow-hidden rounded-lg bg-primary px-6 py-14 text-center text-primary-foreground md:px-16 md:py-20">
            <div
              aria-hidden
              className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-accent/30 blur-3xl"
            />
            <h2 className="relative mx-auto max-w-2xl text-3xl font-semibold md:text-5xl">
              {title}
            </h2>
            <p className="relative mx-auto mt-4 max-w-xl text-primary-foreground/80">
              {description}
            </p>
            <Button
              variant="accent"
              size="lg"
              className="relative mt-8"
              onClick={() => (window.location.href = href)}
            >
              {cta}
            </Button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
```

---

## 10. `Footer.tsx`

```tsx
type Column = { heading: string; links: { label: string; href: string }[] };

export function Footer({
  brand,
  tagline,
  columns,
}: {
  brand: string;
  tagline: string;
  columns: Column[];
}) {
  return (
    <footer className="border-t border-border bg-card">
      <div className="container grid gap-10 py-14 md:grid-cols-[1.5fr_repeat(3,1fr)]">
        <div>
          <p className="flex items-center gap-2 font-heading text-2xl font-bold">
            {brand}
            <span className="h-2 w-2 rounded-full bg-accent" aria-hidden />
          </p>
          <p className="mt-3 max-w-xs text-sm text-muted-foreground">{tagline}</p>
        </div>
        {columns.map((c) => (
          <nav key={c.heading} aria-label={c.heading}>
            <p className="mb-4 text-sm font-semibold">{c.heading}</p>
            <ul className="space-y-3">
              {c.links.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>
      <div className="border-t border-border py-6 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} {brand}. All rights reserved.
      </div>
    </footer>
  );
}
```

---

## 11. Add this to the generator's system prompt

```
## AVAILABLE BLOCKS
Build pages by composing these ready-made components from
@/components/blocks. Prefer them over writing sections from scratch.

- HeroCentered, HeroSplit: choose ONE per page, based on the brief
- Features (bento grid), FeatureSplit (alternating rows)
- Stats, Testimonials, Pricing, FAQ, CTABanner, Footer
- From @/components: Navbar, Section, SectionHeading, Reveal
- From @/components/ui: Button, Card, CardContent, Input

Rules:
- Pass real, specific copy through props. Never lorem ipsum.
- Vary the page: do not use the same block twice in a row.
- Choose HeroSplit when a strong image fits the business, HeroCentered otherwise.
- Only create a new component when none of the blocks fit, and build it from
  the same tokens and base components.
```

---

## Suggested page recipes

| Site type | Block order |
|---|---|
| SaaS / tool | Navbar, HeroCentered, Stats, Features, FeatureSplit, Testimonials, Pricing, FAQ, CTABanner, Footer |
| Local business | Navbar, HeroSplit, Features, FeatureSplit, Testimonials, FAQ, CTABanner, Footer |
| Portfolio | Navbar, HeroSplit, FeatureSplit (projects), Stats, Testimonials, CTABanner, Footer |
| Resume builder | Navbar, HeroSplit, Features, FeatureSplit, Pricing, Testimonials, CTABanner, Footer |

You can include these recipes in the system prompt too, so the model has a proven structure to start from.
