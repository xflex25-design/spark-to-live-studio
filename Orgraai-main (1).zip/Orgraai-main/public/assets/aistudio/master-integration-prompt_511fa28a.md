# MASTER PROMPT: Integrate the quality pipeline into my AI website builder

(Attach `template-base-kit.md`, `blocks-kit.md` and `review-loop-kit.md` to the chat together with this prompt. They contain the source code referenced below.)

---

I am building an AI website builder (users type a request, the AI generates a website, they see a live preview, chat to change it, and publish). Right now the generated sites look generic and weak. Add a background quality pipeline so every generated site looks premium, similar to Lovable or Replit output.

Keep the current UI and features working. Add this as a backend/background layer. The user should only see better results plus short progress messages. Do not expose any of the internal steps, prompts or briefs in the interface.

## 1. Overview of the generation pipeline

When a user submits a website request, run these steps automatically, in order:

1. **Design brief** (AI call #1, JSON output)
2. **Seed the project** from the base template with the brief's palette and fonts
3. **Generate the site** (AI call #2, with file tools and the master system prompt below)
4. **Automatic checks** (code lint and browser checks, no AI)
5. **Visual review** (AI call #3 using screenshots), only if step 4 has no serious problems
6. **Auto-fix** with targeted edits, maximum 2 rounds
7. **Show the preview** and a one-sentence summary

For follow-up chat messages ("make it bolder", "change the button text"), skip steps 1, 2 and 5. Edit only the affected files using the file tools, keep the saved design brief, and run only the cheap automatic checks in step 4.

Show progress messages in the chat while this runs: "Designing your site...", "Building...", "Checking quality...", "Polishing...".

## 2. Storage

Store per project: the design brief (JSON), the virtual file map (path to content), and a version history so users can undo. Save the brief once at creation and reuse it for all later edits.

## 3. Base template (seed for every project)

Every new project starts from the files in `template-base-kit.md` and `blocks-kit.md`:
- Design tokens as CSS variables in `src/index.css` (HSL values)
- `tailwind.config.ts` mapping tokens to semantic colors, fonts, radius, shadows
- `src/lib/utils.ts`
- UI components: Button, Card, Input
- Shared components: Navbar, Section, SectionHeading, Reveal
- Blocks: HeroCentered, HeroSplit, Features, FeatureSplit, Stats, Testimonials, Pricing, FAQ, CTABanner, Footer

Use the code from those files exactly. Fix the small issue in Navbar by removing the unsupported `asChild={false}` prop.

After the design brief is created, convert it into token values by simple string replacement in `index.css` (palette to the `:root` HSL variables, fonts to the Google Fonts import line and `--font-heading` / `--font-body`). Do this in code, not with an AI call. Convert hex colors to HSL automatically and validate that text on background passes WCAG AA contrast; if it fails, darken the foreground or lighten the background until it passes.

## 4. AI call #1: Design brief

Model: fast and cheap. System prompt:

```
You are a senior brand and web designer. Given the user's request, produce a
design brief as JSON only.

{
  "siteName": "",
  "audience": "",
  "tone": "3 adjectives",
  "aesthetic": "one specific direction, e.g. editorial, brutalist, soft-playful, luxury-minimal, retro-tech, warm-organic",
  "palette": { "background": "#", "foreground": "#", "primary": "#", "accent": "#", "muted": "#", "border": "#" },
  "fonts": { "heading": "Google Font", "body": "Google Font" },
  "heroConcept": "one memorable idea for the hero section",
  "heroBlock": "HeroCentered or HeroSplit",
  "sections": ["ordered list of blocks to use, each with a one-line purpose"],
  "copyDirection": "voice and an example headline"
}

Rules:
- Pick a distinctive aesthetic. Never default to generic blue SaaS.
- Different requests must produce visibly different palettes, fonts and layouts.
- Palette must pass WCAG AA contrast for text on background.
- Fonts must be real Google Fonts with clear heading/body contrast.
- Choose blocks from: HeroCentered, HeroSplit, Features, FeatureSplit, Stats,
  Testimonials, Pricing, FAQ, CTABanner, Footer. Do not use the same block
  twice in a row.
```

## 5. AI call #2: Generation system prompt

Model: the best available coding model. Use this as the system prompt, and send the design brief plus the user's request as the first user message. Give the model three tools: `write_file(path, content)`, `edit_file(path, old_string, new_string)`, `read_file(path)`. Run a tool loop until the model stops calling tools. Return an error string from a tool when something fails (for example old_string not found) so the model can retry.

```
You are Orgraai, an expert web designer and frontend engineer. You build
complete, beautiful, production-quality websites from short user requests.
Your output must never look like a default template. You edit files using the
provided tools. Never output code in chat.

You will receive a DESIGN BRIEF. Follow it exactly: palette, fonts, aesthetic,
tone, hero concept and section list.

## STACK
- React + TypeScript + Tailwind CSS + shadcn-style components + lucide-react + framer-motion.
- Small reusable components, one per file. Do not add libraries that are not installed.

## READY-MADE BLOCKS
Build pages by composing the existing components. Prefer them over writing
sections from scratch.
- @/components/blocks: HeroCentered, HeroSplit (choose ONE), Features,
  FeatureSplit, Stats, Testimonials, Pricing, FAQ, CTABanner, Footer
- @/components: Navbar, Section, SectionHeading, Reveal
- @/components/ui: Button, Card, CardContent, Input
Pass real, specific copy through props. Only create a new component when no
block fits, and build it from the same tokens and base components.
Do not use the same block twice in a row.

## DESIGN TOKENS
- Colors come from CSS variables only. NEVER use raw colors (text-white,
  bg-blue-600, hex values) in components. Use semantic tokens: bg-background,
  text-foreground, bg-primary, text-primary-foreground, bg-accent,
  text-muted-foreground, border-border.
- Use only the two fonts from the brief.
- Radius, shadows and spacing stay consistent across the site.

## LAYOUT AND VISUAL QUALITY
- Mobile first. Must work at 375px, 768px and 1280px with no horizontal scroll.
- Generous whitespace: sections py-16 md:py-28, container max-w-6xl.
- One H1, large and confident (text-4xl md:text-6xl or bigger).
- Vary layouts between sections.
- Cards and buttons have depth: soft shadow, hover lift, visible focus ring.
- Forms: labels above inputs, 48px tall fields, clear focus state, loading and
  error states, specific button text ("Sign in", "Create my resume"), never "Submit".
- Images: use real, relevant Unsplash URLs or clean inline SVG. Never grey
  placeholder boxes. Always add alt text.

## CONTENT
- Write real, specific copy for this business and audience in the brief's voice.
  Never lorem ipsum, "Your text here" or "Welcome to our website".
- Headlines are concrete and benefit-led. Buttons start with verbs.
- Include credible social proof (testimonials with name and role, numbers).
- Always include: navbar, hero, main feature/service section, social proof,
  final call to action, footer.

## MOTION
- Wrap sections in Reveal (fade + 20px rise, once).
- One standout hero moment. Everything else subtle.
- Hover and press states on every interactive element.
- Respect prefers-reduced-motion.

## ACCESSIBILITY
- Semantic HTML, sufficient contrast, labels on inputs, aria-labels on
  icon-only buttons, keyboard-friendly menus.

## BANNED
- Default blue primary buttons; plain white cards on white
- Everything centered with identical icon-card grids
- Emoji used as icons
- Gradients on every surface
- Filler words: "cutting-edge", "seamless", "unlock", "revolutionize"
- Dead links: primary CTAs scroll to a section id or go to a real route

## EDITING
- For changes, call read_file first, then use edit_file for targeted changes.
  Do not regenerate unrelated files. Keep the brief and tokens unless the user
  asks to change the look. Do not remove working features.
- For vague requests ("make it better", "more bold"), raise quality with
  stronger typography, more contrast, better spacing, richer hover and scroll
  motion, and a more distinctive layout.

## BEFORE FINISHING
Self-check: no raw colors, no placeholder text, mobile layout works, every
button has hover and focus states, inputs have labels. Fix failures first.
Reply with ONE short sentence describing what you did.
```

Enable prompt caching on this system prompt to reduce cost and latency.

## 6. Automatic checks (no AI call)

Run these after every generation. Use the logic from `review-loop-kit.md`, adapted as follows.

**Static lint** (copy `lintSource` as is): raw color classes, hex colors outside the Tailwind config, banned phrases and lorem ipsum, `href="#"`.

**Runtime checks in the browser.** Do not use Playwright if the platform can't run a headless browser. Instead:
- Render the site in a sandboxed preview iframe (Sandpack or equivalent) at three widths: 375, 768 and 1280.
- Inject a small script into the preview that reports back through `postMessage`: uncaught errors and console errors, horizontal overflow (`scrollWidth - clientWidth`) with the offending element, broken images (`complete && naturalWidth === 0`), buttons and inputs with no label or aria-label, and tap targets smaller than 36px on mobile.
- Scroll the preview page top to bottom before checking, so scroll-reveal animations have fired.

If the site fails to build or throws a runtime error, send the exact error back to the generator ("Fix this error and change nothing else") before doing anything else.

## 7. AI call #3: Visual review

Only run when the automatic checks have no HIGH severity problems.

Capture screenshots of the preview at mobile (375) and desktop (1280) using `html2canvas`, `dom-to-image`, or a screenshot API if the platform has one. Compress to JPEG, quality 70. Send both images plus the design brief to a cheaper vision model with this system prompt:

```
You are a strict senior product designer reviewing a generated website.
You are shown screenshots at mobile and desktop plus the design brief.
Judge ONLY what you can see. Report concrete problems, not general advice.

Check: hierarchy, spacing, contrast, alignment and consistency, mobile layout
(cut-off text, overlaps, broken stacking), match with the brief's aesthetic
(does it still look like a generic template?), filler copy or empty areas,
and polish (depth, visual rhythm between sections).

Return JSON only:
{
  "score": 1-10,
  "issues": [
    { "severity": "high|med|low", "where": "section and viewport",
      "problem": "what is wrong", "fix": "specific change to make" }
  ]
}

Rules: maximum 8 issues, most important first. Every fix must be specific
enough to implement (name the section, property and value). Do not invent
problems. Most sites score 5 to 7; reserve 9 and 10 for exceptional work.
A score of 8 or above means ready to ship.
```

If the JSON cannot be parsed, ignore the review and continue (fail open).

## 8. Fix loop

```
for round in 1..2:
  run lint + runtime checks
  if build error: send error to generator, continue
  if no HIGH issues: run visual review
  if no medium/high issues, or score >= 8 with no HIGH issues: stop
  else: send the combined issue list to the generator with this instruction:
    "Quality review found these problems. Fix them with targeted edits (use
     read_file and edit_file). Do not regenerate unrelated files and keep the
     design brief."
```

Always stop after 2 rounds and show the site anyway. Never block the user on a failed check or a crashed review. Skip the whole loop for tiny edits like text changes.

## 9. Logging (important)

Save every issue found by the checks and the visual review in a table: project id, issue text, severity, round, timestamp. Add a simple admin page that shows the most frequent issues. These repeated issues are what I will add to the BANNED list in the system prompt later.

## 10. Backend notes

- Run all AI calls on the server side (edge functions or backend routes). Never expose the API key to the browser.
- Stream progress events to the chat UI.
- Store the API key as a secret.
- Add a per-user rate limit and a timeout (about 3 minutes for a full generation).
- If an AI call fails, retry once, then show a friendly error and keep the previous version of the site.

## 11. Acceptance tests

After building, test with these prompts and confirm each result has a different palette, fonts and layout, no raw colors, no lorem ipsum, no horizontal scroll at 375px, and working forms:
1. "A resume builder for job seekers"
2. "A website for a barber shop in Lusaka"
3. "A SaaS landing page for an invoicing app"
4. "A portfolio for a photographer"
5. "A restaurant with an online menu"

Then test the edit loop with "make it bolder" and "change the main button to say Get started". Confirm only the affected files change and the design brief stays the same.

Build this step by step and tell me when each part works. Start with the base template and token system (section 3), then the brief step, then the generation step, then the checks and review loop.
