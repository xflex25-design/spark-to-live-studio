# Screenshot Review Loop Kit

Flow: generate site -> run cheap automatic checks -> screenshot desktop + mobile -> Claude reviews the screenshots -> feed problems back to the generator -> repeat (max 2 rounds).

Automatic checks run first because they are free, instant and catch the most common bugs. The vision review only runs after they pass.

Install on the server:

```
npm i playwright @anthropic-ai/sdk
npx playwright install chromium
```

---

## 1. `server/review/render.ts` (build and serve the generated site)

Writes the generated files to a temp folder that already contains the template's `node_modules`, then starts Vite and returns the URL.

```ts
import { mkdtemp, writeFile, mkdir, symlink } from "node:fs/promises";
import { dirname, join } from "node:path";
import { tmpdir } from "node:os";
import { spawn, type ChildProcess } from "node:child_process";

const TEMPLATE_DIR = join(process.cwd(), "template"); // has node_modules installed

export type RenderedSite = {
  url: string;
  dir: string;
  stop: () => void;
};

export async function renderSite(files: Record<string, string>): Promise<RenderedSite> {
  const dir = await mkdtemp(join(tmpdir(), "site-"));

  // Reuse installed dependencies instead of running npm install every time
  await symlink(join(TEMPLATE_DIR, "node_modules"), join(dir, "node_modules"), "dir");

  for (const [path, content] of Object.entries(files)) {
    const full = join(dir, path);
    await mkdir(dirname(full), { recursive: true });
    await writeFile(full, content);
  }

  const port = 4100 + Math.floor(Math.random() * 800);
  const proc: ChildProcess = spawn(
    "npx",
    ["vite", "--port", String(port), "--strictPort", "--host", "127.0.0.1"],
    { cwd: dir, stdio: ["ignore", "pipe", "pipe"] }
  );

  let buildErrors = "";
  proc.stderr?.on("data", (d) => (buildErrors += d.toString()));

  const url = `http://127.0.0.1:${port}`;
  await waitForServer(url, 20000, () => buildErrors);

  return { url, dir, stop: () => proc.kill("SIGTERM") };
}

async function waitForServer(url: string, timeoutMs: number, getErrors: () => string) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(url);
      if (res.ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`Dev server did not start. Output:\n${getErrors().slice(-2000)}`);
}
```

---

## 2. `server/review/checks.ts` (automatic checks, no AI)

```ts
import { chromium, type Page } from "playwright";
import type { RenderedSite } from "./render";

export type Issue = {
  severity: "high" | "med" | "low";
  where: string;
  problem: string;
  fix: string;
};

/** Static lint on the source files */
export function lintSource(files: Record<string, string>): Issue[] {
  const issues: Issue[] = [];

  const rawColor =
    /\b(?:bg|text|border|ring|from|to|via|fill|stroke)-(?:white|black|(?:slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)-\d{2,3})\b/g;
  const hex = /#[0-9a-fA-F]{3,8}\b/g;
  const banned = /lorem ipsum|your text here|welcome to our website|cutting-edge|seamless|unlock the|revolutionize/i;

  for (const [path, code] of Object.entries(files)) {
    if (!/\.(tsx|ts|jsx)$/.test(path)) continue;

    const raw = code.match(rawColor);
    if (raw) {
      issues.push({
        severity: "high",
        where: path,
        problem: `Raw color classes used: ${[...new Set(raw)].slice(0, 4).join(", ")}`,
        fix: "Replace with semantic tokens (bg-background, text-foreground, bg-primary, text-muted-foreground, border-border).",
      });
    }

    const hexes = code.match(hex);
    if (hexes && !path.endsWith("tailwind.config.ts")) {
      issues.push({
        severity: "med",
        where: path,
        problem: `Hard-coded hex colors: ${[...new Set(hexes)].slice(0, 3).join(", ")}`,
        fix: "Use CSS variable tokens instead of hex values.",
      });
    }

    const b = code.match(banned);
    if (b) {
      issues.push({
        severity: "med",
        where: path,
        problem: `Placeholder or banned phrase found: "${b[0]}"`,
        fix: "Rewrite with specific, real copy for this business.",
      });
    }

    if (/href=["']#["']/.test(code)) {
      issues.push({
        severity: "low",
        where: path,
        problem: 'Dead link href="#"',
        fix: "Point to a real section id or route.",
      });
    }
  }
  return issues;
}

/** Runtime checks in a real browser */
export async function runtimeChecks(site: RenderedSite) {
  const browser = await chromium.launch();
  const issues: Issue[] = [];
  const shots: { label: string; base64: string }[] = [];

  const viewports = [
    { label: "mobile-375", width: 375, height: 812, isMobile: true },
    { label: "tablet-768", width: 768, height: 1024, isMobile: false },
    { label: "desktop-1280", width: 1280, height: 800, isMobile: false },
  ];

  for (const vp of viewports) {
    const context = await browser.newContext({
      viewport: { width: vp.width, height: vp.height },
      isMobile: vp.isMobile,
      deviceScaleFactor: 1,
    });
    const page = await context.newPage();

    const consoleErrors: string[] = [];
    page.on("pageerror", (e) => consoleErrors.push(e.message));
    page.on("console", (m) => m.type() === "error" && consoleErrors.push(m.text()));

    await page.goto(site.url, { waitUntil: "networkidle", timeout: 20000 });
    await triggerScrollReveals(page);

    // 1. Console / runtime errors
    if (consoleErrors.length) {
      issues.push({
        severity: "high",
        where: vp.label,
        problem: `Runtime errors: ${consoleErrors.slice(0, 3).join(" | ")}`,
        fix: "Fix the error shown; check imports, props and undefined values.",
      });
    }

    // 2. Horizontal overflow
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth
    );
    if (overflow > 1) {
      const culprit = await page.evaluate(() => {
        const vw = document.documentElement.clientWidth;
        const el = [...document.querySelectorAll("body *")].find(
          (e) => e.getBoundingClientRect().right > vw + 1
        );
        return el ? `${el.tagName.toLowerCase()}.${(el as HTMLElement).className}`.slice(0, 120) : "unknown";
      });
      issues.push({
        severity: "high",
        where: vp.label,
        problem: `Horizontal scroll: page is ${overflow}px wider than the screen. Likely element: ${culprit}`,
        fix: "Add max-w-full, flex-wrap, or reduce fixed widths and padding on small screens.",
      });
    }

    // 3. Broken images
    const broken = await page.evaluate(() =>
      [...document.images]
        .filter((i) => i.complete && i.naturalWidth === 0)
        .map((i) => i.src.slice(0, 80))
    );
    if (broken.length) {
      issues.push({
        severity: "high",
        where: vp.label,
        problem: `${broken.length} image(s) failed to load: ${broken.slice(0, 2).join(", ")}`,
        fix: "Replace with working image URLs or inline SVG.",
      });
    }

    // 4. Tiny tap targets on mobile
    if (vp.isMobile) {
      const tiny = await page.evaluate(() =>
        [...document.querySelectorAll("a, button")]
          .filter((e) => {
            const r = e.getBoundingClientRect();
            return r.width > 0 && (r.height < 36 || r.width < 36) && !e.closest("nav a");
          })
          .slice(0, 3)
          .map((e) => (e.textContent || e.getAttribute("aria-label") || "").trim().slice(0, 30))
      );
      if (tiny.length) {
        issues.push({
          severity: "low",
          where: vp.label,
          problem: `Tap targets smaller than 36px: ${tiny.join(", ")}`,
          fix: "Increase padding so buttons and links are at least 44px tall.",
        });
      }
    }

    // 5. Missing form labels, empty buttons
    const a11y = await page.evaluate(() => {
      const unlabeled = [...document.querySelectorAll("input, textarea, select")].filter(
        (i) => !i.id || !document.querySelector(`label[for="${i.id}"]`)
      ).length;
      const emptyBtns = [...document.querySelectorAll("button")].filter(
        (b) => !b.textContent?.trim() && !b.getAttribute("aria-label")
      ).length;
      return { unlabeled, emptyBtns };
    });
    if (a11y.unlabeled || a11y.emptyBtns) {
      issues.push({
        severity: "med",
        where: vp.label,
        problem: `${a11y.unlabeled} unlabeled input(s), ${a11y.emptyBtns} button(s) without text or aria-label`,
        fix: "Add <label htmlFor> to inputs and aria-label to icon-only buttons.",
      });
    }

    const png = await page.screenshot({ fullPage: true, type: "jpeg", quality: 70 });
    shots.push({ label: vp.label, base64: png.toString("base64") });
    await context.close();
  }

  await browser.close();

  // Remove duplicate issues reported at several widths
  const seen = new Set<string>();
  const unique = issues.filter((i) => {
    const key = `${i.severity}|${i.problem}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return { issues: unique, shots };
}

/** Scroll the page so framer-motion whileInView animations fire before the screenshot */
async function triggerScrollReveals(page: Page) {
  await page.evaluate(async () => {
    const step = window.innerHeight * 0.7;
    for (let y = 0; y < document.body.scrollHeight; y += step) {
      window.scrollTo(0, y);
      await new Promise((r) => setTimeout(r, 120));
    }
    window.scrollTo(0, 0);
  });
  await page.waitForTimeout(600);
}
```

---

## 3. `server/review/vision.ts` (Claude reviews the screenshots)

```ts
import Anthropic from "@anthropic-ai/sdk";
import type { Issue } from "./checks";

const client = new Anthropic();

const REVIEW_PROMPT = `You are a strict senior product designer reviewing a generated website.
You are shown screenshots at mobile (375px), tablet (768px) and desktop (1280px).
You are also given the design brief the site was meant to follow.

Judge ONLY what you can see. Report concrete problems, not general advice.

Check:
1. Hierarchy: is there one clear focal point per section? Is the H1 dominant?
2. Spacing: cramped areas, uneven gaps, sections that feel too tight or too empty.
3. Contrast: text that is hard to read on its background.
4. Alignment and consistency: elements out of line, mismatched radii or sizes.
5. Mobile layout: cut-off text, overlapping elements, huge or tiny type, stacked layouts that look broken.
6. Brief match: does the look match the brief's aesthetic, palette and tone? Does it still look like a generic template?
7. Content: filler copy, vague headlines, missing images or empty areas.
8. Polish: missing depth, flat sections, no visual rhythm between sections.

Return JSON only, no prose:
{
  "score": 1-10,
  "issues": [
    { "severity": "high|med|low", "where": "section and viewport", "problem": "what is wrong", "fix": "specific change to make" }
  ]
}

Rules:
- Maximum 8 issues, most important first.
- Every fix must be specific enough to implement (name the section, the property, the value).
- Do not invent problems. If it looks good, return a high score and an empty issues array.
- Score 8 or above means ready to ship.`;

export async function visionReview(
  shots: { label: string; base64: string }[],
  brief: string
): Promise<{ score: number; issues: Issue[] }> {
  const content: Anthropic.ContentBlockParam[] = [
    { type: "text", text: `DESIGN BRIEF:\n${brief}` },
  ];

  for (const s of shots) {
    content.push({ type: "text", text: `Screenshot: ${s.label}` });
    content.push({
      type: "image",
      source: { type: "base64", media_type: "image/jpeg", data: s.base64 },
    });
  }

  const res = await client.messages.create({
    model: "claude-sonnet-4-5", // use your preferred current model
    max_tokens: 2000,
    system: REVIEW_PROMPT,
    messages: [{ role: "user", content }],
  });

  const text = res.content[0].type === "text" ? res.content[0].text : "{}";
  try {
    const json = JSON.parse(text.replace(/```json|```/g, "").trim());
    return { score: json.score ?? 7, issues: json.issues ?? [] };
  } catch {
    return { score: 7, issues: [] }; // fail open: never block the user on a parse error
  }
}
```

---

## 4. `server/review/loop.ts` (the full generate -> review -> fix cycle)

```ts
import { renderSite } from "./render";
import { lintSource, runtimeChecks, type Issue } from "./checks";
import { visionReview } from "./vision";

type GenerateFn = (prompt: string, files: Record<string, string>) => Promise<Record<string, string>>;

const MAX_ROUNDS = 2;
const PASS_SCORE = 8;

function formatIssues(issues: Issue[]): string {
  return issues
    .sort((a, b) => order(a.severity) - order(b.severity))
    .map((i, n) => `${n + 1}. [${i.severity.toUpperCase()}] ${i.where}: ${i.problem}\n   Fix: ${i.fix}`)
    .join("\n");
}
const order = (s: Issue["severity"]) => ({ high: 0, med: 1, low: 2 }[s]);

export async function generateWithReview(
  userPrompt: string,
  brief: string,
  generate: GenerateFn,
  onProgress?: (msg: string) => void
) {
  let files = await generate(userPrompt, {});

  for (let round = 1; round <= MAX_ROUNDS; round++) {
    onProgress?.(`Checking quality (round ${round})...`);

    // Cheap checks first
    const lint = lintSource(files);

    let site;
    try {
      site = await renderSite(files);
    } catch (err: any) {
      // Build failed: send the error straight back to the generator
      files = await generate(
        `The project failed to build. Fix this error and change nothing else:\n${err.message}`,
        files
      );
      continue;
    }

    try {
      const { issues: runtime, shots } = await runtimeChecks(site);
      const blocking = [...lint, ...runtime].filter((i) => i.severity !== "low");

      // Only spend a vision call when the cheap checks are clean
      let visual: Issue[] = [];
      let score = 0;
      if (blocking.filter((i) => i.severity === "high").length === 0) {
        onProgress?.("Reviewing the design...");
        const v = await visionReview(shots, brief);
        visual = v.issues;
        score = v.score;
      }

      const all = [...lint, ...runtime, ...visual];
      const mustFix = all.filter((i) => i.severity !== "low");

      if (mustFix.length === 0 || (score >= PASS_SCORE && !all.some((i) => i.severity === "high"))) {
        return { files, score, remaining: all };
      }

      onProgress?.("Improving the design...");
      files = await generate(
        `Quality review found these problems. Fix them with targeted edits (use read_file and edit_file). ` +
          `Do not regenerate unrelated files and keep the design brief.\n\n${formatIssues(all)}`,
        files
      );
    } finally {
      site.stop();
    }
  }

  return { files, score: null, remaining: [] };
}
```

Use it in your endpoint instead of calling `generate` directly:

```ts
app.post("/generate", async (req, res) => {
  const { prompt } = req.body;
  const { brief } = await makeBrief(prompt);          // step 1 from the first kit
  const result = await generateWithReview(
    prompt,
    brief,
    (p, f) => generate(p, f),                        // your tool-loop function
    (msg) => sendProgressToClient(msg)               // optional: stream status to the UI
  );
  res.json({ files: result.files, score: result.score });
});
```

---

## 5. Cost and speed controls

- **Cheap checks first.** Lint and runtime checks cost nothing. Skip the vision call when they find high-severity problems, because the fix is already known.
- **Cap at 2 rounds.** A third round rarely helps and doubles the wait.
- **Use JPEG at quality 70** and full-page screenshots at three widths. If cost matters, send only mobile and desktop.
- **Use a cheaper model for review** (a smaller Claude model is usually enough for spotting layout problems) and your best model for generation.
- **Run only on first build and big changes.** For small edits like "change the button text", skip the loop.
- **Fail open.** If a check crashes or JSON parsing fails, return the site anyway. A review bug should never block the user.

## 6. Common problems

| Problem | Cause | Fix |
|---|---|---|
| Screenshots show blank sections | Scroll animations haven't fired | `triggerScrollReveals` handles this; increase the wait if needed |
| Review always scores 10 | Prompt too lenient | Add "Most sites score 5 to 7. Reserve 9 and 10 for exceptional work." |
| Review nitpicks forever | No pass threshold | Keep `PASS_SCORE = 8` and the 2-round cap |
| Images always "broken" | Sandbox has no internet | Allow outbound requests to the image host, or use inline SVG |
| Slow review | Cold Chromium start | Keep one browser instance alive between runs |
| Same issues reappear after fix | Model regenerates whole files | Reinforce "use edit_file, change only the listed items" |

## 7. Build order

1. Run `lintSource` on 10 sample generations. Fix your system prompt wherever it triggers often.
2. Add `runtimeChecks` and confirm it catches overflow and broken images on a deliberately broken page.
3. Add `visionReview` and compare its score against your own opinion on 10 sites. Tune the prompt until they agree.
4. Wire up `generateWithReview` and stream progress messages to the UI ("Checking quality...", "Improving the design...").
5. Log every issue found. The most frequent ones belong in the system prompt's banned list so the model stops making them in the first place.
