# AI Website Builder Starter Kit

Stack: React + Vite + Tailwind + shadcn/ui, Claude API with tool use, Sandpack for live preview.

---

## 1. Project structure

```
site-builder/
├── server/
│   ├── index.ts            # Express API: /generate, /edit
│   ├── prompts/
│   │   ├── brief.ts        # Step 1 prompt: design brief
│   │   ├── system.ts       # Step 2 prompt: code generation rules
│   │   └── review.ts       # Step 3 prompt: critique pass
│   └── tools.ts            # write_file, edit_file, read_file tool defs
├── web/
│   ├── src/
│   │   ├── App.tsx         # Builder UI: chat panel + preview panel
│   │   ├── components/
│   │   │   ├── ChatPanel.tsx
│   │   │   └── Preview.tsx # Sandpack wrapper
│   │   └── lib/files.ts    # In-memory virtual file system
│   └── package.json
└── template/               # Base project every generated site starts from
    ├── package.json        # react, tailwind, framer-motion, lucide-react
    ├── tailwind.config.ts  # Token-based theme (CSS variables)
    ├── src/index.css       # :root tokens, base styles
    └── src/components/ui/  # Pre-made shadcn components (Button, Card, etc.)
```

The generated site is a virtual file map: `{ "/src/App.tsx": "...", ... }`. Seed it from `template/`, let the model edit it through tools, and feed it to Sandpack.

---

## 2. Step 1: Design brief prompt

Run this first, before any code. Output is JSON.

```
You are a senior brand and web designer. Given the user's request, produce a
design brief as JSON only.

{
  "siteName": "",
  "audience": "",
  "tone": "3 adjectives",
  "aesthetic": "one specific direction, e.g. editorial, brutalist, soft-playful, luxury-minimal, retro-tech",
  "palette": {
    "background": "#", "foreground": "#", "primary": "#",
    "accent": "#", "muted": "#"
  },
  "fonts": { "heading": "Google Font", "body": "Google Font" },
  "heroConcept": "one memorable idea for the hero section",
  "sections": ["ordered list of sections with a one-line purpose each"],
  "copyDirection": "voice and example headline"
}

Rules:
- Pick a distinctive aesthetic. Do not default to generic blue SaaS.
- Palette must pass WCAG AA contrast for text on background.
- Fonts must be real Google Fonts with a clear heading/body contrast.
```

---

## 3. Step 2: Code generation system prompt

```
You are an expert frontend engineer and designer building a website inside a
fixed React + Vite + Tailwind + shadcn/ui project. You edit files using the
provided tools (write_file, edit_file, read_file). Never output code in chat.

You will receive a DESIGN BRIEF. Follow it exactly.

## Stack rules
- React 18, TypeScript, Tailwind CSS, shadcn/ui components from
  @/components/ui, lucide-react icons, framer-motion for animation.
- Build small components in /src/components. One component per file.
- Do not add dependencies that are not in package.json.

## Design token rules
- Define the brief's palette as CSS variables in src/index.css (HSL) and map
  them in tailwind.config.ts.
- NEVER use raw color classes like text-white, bg-blue-500, or hex values in
  components. Use semantic tokens only: bg-background, text-foreground,
  bg-primary, text-muted-foreground, border-border.
- Load the brief's two Google Fonts and apply them via font-heading and
  font-body. No other fonts.
- Spacing follows Tailwind's scale. Section padding: py-20 md:py-32.
  Container: max-w-6xl mx-auto px-4 md:px-6.

## Layout and quality rules
- Mobile first. Every section must work at 375px, 768px and 1280px.
- Clear type hierarchy: one H1 per page, large and confident
  (text-5xl md:text-7xl for heroes).
- Generous whitespace. Never crowd elements.
- Every interactive element has hover, focus-visible and active states.
- Images: use real, relevant Unsplash URLs or inline SVG. No grey boxes.
  Always include alt text.
- Accessibility: semantic HTML (header, main, section, nav, footer),
  sufficient contrast, labels on inputs, aria-labels on icon buttons.

## Content rules
- Write real, specific copy in the brief's voice. NEVER use lorem ipsum,
  "Your text here", or generic filler like "Welcome to our website".
- Headlines say something concrete. Buttons use verbs ("Start building",
  not "Submit").
- Include credible social proof (testimonials, logos, numbers) written to
  fit the business.

## Required structure (adapt to the brief's sections)
1. Navigation (sticky, with mobile menu)
2. Hero with one memorable moment from the brief's heroConcept
3. Features or services (not a plain 3-icon grid every time; vary layouts)
4. Social proof
5. Secondary section specific to the business (pricing, menu, portfolio...)
6. Final CTA
7. Footer with links

## Motion rules
- Scroll-reveal sections with framer-motion (fade + 20px rise, once).
- One standout hero animation. Everything else subtle.
- Respect prefers-reduced-motion.

## Banned
- Default blue primary buttons
- Everything centered with identical card grids
- Emoji as icons
- Gradients on every surface
- Stock phrases: "cutting-edge", "seamless", "unlock", "revolutionize"
- Placeholder links with href="#" on primary CTAs (scroll to a section id)

## Editing existing sites
When the user asks for a change, call read_file first, then use edit_file for
targeted changes. Do not regenerate unrelated files. Preserve the design
brief unless the user asks to change the look.

When finished, reply with ONE short sentence on what you did.
```

---

## 4. Step 3: Review prompt

Send a screenshot of the rendered preview at desktop and mobile widths.

```
You are a strict design reviewer. Look at these screenshots (desktop and
mobile) of a generated website. List concrete problems only, ordered by
severity, in this format:

- [severity high/med/low] [section] problem -> specific fix

Check: contrast, text overflow, broken mobile layout, cramped spacing,
weak hierarchy, missing hover states, placeholder content, inconsistent
alignment, images that failed to load.

If there are no high or medium problems, reply exactly: APPROVED
```

Feed the list back to the generator as the next user message and loop up to 2 times.

---

## 5. Tool definitions (Claude API)

```ts
// server/tools.ts
export const tools = [
  {
    name: "write_file",
    description: "Create or fully replace a file in the project.",
    input_schema: {
      type: "object",
      properties: {
        path: { type: "string", description: "e.g. /src/components/Hero.tsx" },
        content: { type: "string" },
      },
      required: ["path", "content"],
    },
  },
  {
    name: "edit_file",
    description: "Replace an exact string in an existing file.",
    input_schema: {
      type: "object",
      properties: {
        path: { type: "string" },
        old_string: { type: "string" },
        new_string: { type: "string" },
      },
      required: ["path", "old_string", "new_string"],
    },
  },
  {
    name: "read_file",
    description: "Read a file's current contents.",
    input_schema: {
      type: "object",
      properties: { path: { type: "string" } },
      required: ["path"],
    },
  },
];
```

---

## 6. Server loop (core logic)

```ts
// server/index.ts
import Anthropic from "@anthropic-ai/sdk";
import { tools } from "./tools";
import { BRIEF_PROMPT } from "./prompts/brief";
import { SYSTEM_PROMPT } from "./prompts/system";

const client = new Anthropic();

export async function generate(userPrompt: string, files: Record<string, string>) {
  // Step 1: design brief
  const briefRes = await client.messages.create({
    model: "claude-sonnet-4-5", // use your preferred current model
    max_tokens: 2000,
    system: BRIEF_PROMPT,
    messages: [{ role: "user", content: userPrompt }],
  });
  const brief = briefRes.content[0].type === "text" ? briefRes.content[0].text : "";

  // Step 2: code generation with tool loop
  const messages: Anthropic.MessageParam[] = [
    { role: "user", content: `DESIGN BRIEF:\n${brief}\n\nREQUEST:\n${userPrompt}` },
  ];

  while (true) {
    const res = await client.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 16000,
      system: SYSTEM_PROMPT,
      tools,
      messages,
    });

    messages.push({ role: "assistant", content: res.content });
    if (res.stop_reason !== "tool_use") break;

    const results: Anthropic.ToolResultBlockParam[] = [];
    for (const block of res.content) {
      if (block.type !== "tool_use") continue;
      const input = block.input as any;
      let output = "ok";

      if (block.name === "write_file") files[input.path] = input.content;
      else if (block.name === "read_file") output = files[input.path] ?? "File not found";
      else if (block.name === "edit_file") {
        const current = files[input.path];
        if (!current?.includes(input.old_string)) output = "Error: old_string not found";
        else files[input.path] = current.replace(input.old_string, input.new_string);
      }
      results.push({ type: "tool_result", tool_use_id: block.id, content: output });
    }
    messages.push({ role: "user", content: results });
  }

  return files; // send to the frontend and render in Sandpack
}
```

---

## 7. Preview component

```tsx
// web/src/components/Preview.tsx
import { Sandpack } from "@codesandbox/sandpack-react";

export function Preview({ files }: { files: Record<string, string> }) {
  return (
    <Sandpack
      template="react-ts"
      files={files}
      options={{ showNavigator: false, showTabs: false, editorHeight: 0 }}
      customSetup={{
        dependencies: {
          "framer-motion": "latest",
          "lucide-react": "latest",
          "tailwindcss": "latest",
        },
      }}
    />
  );
}
```

For real Tailwind in Sandpack, include the Tailwind CDN script in `/public/index.html`, or use a WebContainer for a full Vite dev server.

---

## 8. Build order

1. Build `template/` by hand and make sure it looks great with zero AI.
2. Add the `/generate` endpoint and test with 10 different prompts.
3. Add Sandpack preview.
4. Add the edit loop (follow-up chat messages using `edit_file`).
5. Add the screenshot review pass (Playwright for screenshots).
6. Add export (zip download) and deploy (Vercel or Netlify API).

## 9. Tips

- Quality comes from the template and the brief step, not from a longer prompt.
- Keep a test set of 10 prompts and re-run it after every prompt change.
- Cache the system prompt (prompt caching) to cut cost and latency.
- Log every generation so you can find patterns in bad outputs and add them to the banned list.
