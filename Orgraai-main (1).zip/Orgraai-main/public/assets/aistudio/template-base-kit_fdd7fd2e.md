# Base Template Kit

Every generated site starts from these files. The model only changes the CSS variables in `index.css` (from the design brief) and builds pages on top of these components. That is what keeps results consistent and polished.

Dependencies for `package.json`:

```
react, react-dom, vite, typescript, tailwindcss, postcss, autoprefixer,
tailwindcss-animate, class-variance-authority, clsx, tailwind-merge,
framer-motion, lucide-react
```

---

## 1. `src/index.css` (design tokens)

The generator rewrites ONLY the values inside `:root` and the font names.

```css
@import url("https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600&display=swap");

@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    /* HSL values without hsl() so Tailwind can add opacity */
    --background: 36 38% 96%;
    --foreground: 0 0% 10%;

    --card: 0 0% 100%;
    --card-foreground: 0 0% 10%;

    --primary: 165 33% 18%;
    --primary-foreground: 36 38% 96%;

    --accent: 38 78% 56%;
    --accent-foreground: 0 0% 10%;

    --muted: 36 20% 91%;
    --muted-foreground: 0 0% 40%;

    --border: 38 22% 87%;
    --ring: 165 33% 28%;
    --destructive: 0 72% 48%;

    --radius: 0.75rem;

    --font-heading: "Fraunces", Georgia, serif;
    --font-body: "Inter", system-ui, sans-serif;

    --shadow-soft: 0 1px 2px hsl(0 0% 0% / 0.04), 0 8px 24px -8px hsl(0 0% 0% / 0.10);
    --shadow-lift: 0 2px 4px hsl(0 0% 0% / 0.05), 0 16px 40px -12px hsl(0 0% 0% / 0.18);
  }

  * {
    @apply border-border;
  }

  html {
    scroll-behavior: smooth;
  }

  body {
    @apply bg-background text-foreground antialiased;
    font-family: var(--font-body);
  }

  h1, h2, h3, h4 {
    font-family: var(--font-heading);
    @apply tracking-tight;
  }

  ::selection {
    @apply bg-accent text-accent-foreground;
  }

  @media (prefers-reduced-motion: reduce) {
    * {
      animation-duration: 0.01ms !important;
      transition-duration: 0.01ms !important;
      scroll-behavior: auto !important;
    }
  }
}
```

---

## 2. `tailwind.config.ts`

```ts
import type { Config } from "tailwindcss";
import animate from "tailwindcss-animate";

export default {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    container: {
      center: true,
      padding: { DEFAULT: "1rem", md: "1.5rem" },
      screens: { "2xl": "72rem" },
    },
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        destructive: "hsl(var(--destructive))",
        border: "hsl(var(--border))",
        ring: "hsl(var(--ring))",
      },
      fontFamily: {
        heading: "var(--font-heading)",
        body: "var(--font-body)",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      boxShadow: {
        soft: "var(--shadow-soft)",
        lift: "var(--shadow-lift)",
      },
    },
  },
  plugins: [animate],
} satisfies Config;
```

---

## 3. `src/lib/utils.ts`

```ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

---

## 4. `src/components/ui/button.tsx`

```tsx
import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md font-medium " +
    "transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 " +
    "focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background " +
    "active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary:
          "bg-primary text-primary-foreground shadow-soft hover:bg-primary/90 hover:shadow-lift hover:-translate-y-0.5",
        accent:
          "bg-accent text-accent-foreground shadow-soft hover:brightness-95 hover:shadow-lift hover:-translate-y-0.5",
        outline:
          "border border-border bg-card text-foreground hover:bg-muted",
        ghost: "text-foreground hover:bg-muted",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        sm: "h-9 px-4 text-sm",
        md: "h-11 px-6 text-sm",
        lg: "h-12 px-8 text-base",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, children, disabled, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(buttonVariants({ variant, size }), className)}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
      {children}
    </button>
  )
);
Button.displayName = "Button";
```

---

## 5. `src/components/ui/card.tsx`

```tsx
import * as React from "react";
import { cn } from "@/lib/utils";

export function Card({
  className,
  hoverable = false,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { hoverable?: boolean }) {
  return (
    <div
      className={cn(
        "rounded-lg border border-border bg-card text-card-foreground shadow-soft",
        hoverable &&
          "transition-all duration-300 hover:-translate-y-1 hover:shadow-lift",
        className
      )}
      {...props}
    />
  );
}

export const CardContent = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("p-6 md:p-8", className)} {...props} />
);
```

---

## 6. `src/components/ui/input.tsx` (with label, error, password toggle)

```tsx
import * as React from "react";
import { Eye, EyeOff } from "lucide-react";
import { cn } from "@/lib/utils";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className, type = "text", id, ...props }, ref) => {
    const [show, setShow] = React.useState(false);
    const isPassword = type === "password";
    const inputId = id ?? label.toLowerCase().replace(/\s+/g, "-");

    return (
      <div className="space-y-2">
        <label htmlFor={inputId} className="text-sm font-medium text-foreground">
          {label}
        </label>
        <div className="relative">
          <input
            ref={ref}
            id={inputId}
            type={isPassword && show ? "text" : type}
            aria-invalid={!!error}
            className={cn(
              "h-12 w-full rounded-md border border-border bg-card px-4 text-base " +
                "placeholder:text-muted-foreground transition-shadow " +
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              isPassword && "pr-12",
              error && "border-destructive focus-visible:ring-destructive",
              className
            )}
            {...props}
          />
          {isPassword && (
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              aria-label={show ? "Hide password" : "Show password"}
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
            >
              {show ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          )}
        </div>
        {error && <p className="text-sm text-destructive">{error}</p>}
      </div>
    );
  }
);
Input.displayName = "Input";
```

---

## 7. `src/components/Reveal.tsx` (scroll animation wrapper)

```tsx
import { motion, useReducedMotion } from "framer-motion";

export function Reveal({
  children,
  delay = 0,
  className,
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduce ? false : { opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.4, delay, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}
```

---

## 8. `src/components/Section.tsx`

```tsx
import { cn } from "@/lib/utils";

export function Section({
  id,
  className,
  children,
}: {
  id?: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className={cn("py-16 md:py-28", className)}>
      <div className="container">{children}</div>
    </section>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="mb-12 max-w-2xl md:mb-16">
      {eyebrow && (
        <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-accent-foreground/70">
          {eyebrow}
        </p>
      )}
      <h2 className="text-3xl font-semibold md:text-5xl">{title}</h2>
      {description && (
        <p className="mt-4 text-lg text-muted-foreground">{description}</p>
      )}
    </div>
  );
}
```

---

## 9. `src/components/Navbar.tsx` (sticky, blur, slide-in mobile menu)

```tsx
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

type NavLink = { label: string; href: string };

export function Navbar({
  brand,
  links,
  cta,
}: {
  brand: string;
  links: NavLink[];
  cta?: NavLink;
}) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <a href="#top" className="flex items-center gap-2 font-heading text-2xl font-bold">
          {brand}
          <span className="h-2 w-2 rounded-full bg-accent" aria-hidden />
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Main">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              {l.label}
            </a>
          ))}
          {cta && (
            <Button size="sm" asChild={false} onClick={() => (window.location.href = cta.href)}>
              {cta.label}
            </Button>
          )}
        </nav>

        <button
          className="rounded-md p-2 hover:bg-muted md:hidden"
          onClick={() => setOpen(true)}
          aria-label="Open menu"
        >
          <Menu className="h-6 w-6" />
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="fixed inset-0 z-40 bg-foreground/30"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
            />
            <motion.aside
              className="fixed right-0 top-0 z-50 flex h-full w-4/5 max-w-sm flex-col bg-card p-6 shadow-lift"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.25 }}
            >
              <button
                className="mb-8 self-end rounded-md p-2 hover:bg-muted"
                onClick={() => setOpen(false)}
                aria-label="Close menu"
              >
                <X className="h-6 w-6" />
              </button>
              <nav className="flex flex-col gap-2" aria-label="Mobile">
                {links.map((l) => (
                  <a
                    key={l.href}
                    href={l.href}
                    onClick={() => setOpen(false)}
                    className="rounded-md px-3 py-3 font-heading text-2xl hover:bg-muted"
                  >
                    {l.label}
                  </a>
                ))}
              </nav>
              {cta && (
                <Button
                  size="lg"
                  className="mt-auto"
                  onClick={() => (window.location.href = cta.href)}
                >
                  {cta.label}
                </Button>
              )}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
```

---

## 10. Example page using the kit (`src/App.tsx`)

Shows how the generator should compose pages: it only writes content and layout, never raw styles.

```tsx
import { Navbar } from "@/components/Navbar";
import { Section, SectionHeading } from "@/components/Section";
import { Reveal } from "@/components/Reveal";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function App() {
  return (
    <div id="top">
      <Navbar
        brand="Resume"
        links={[
          { label: "Templates", href: "#templates" },
          { label: "Reviews", href: "#reviews" },
        ]}
        cta={{ label: "Sign in", href: "#signin" }}
      />

      <Section className="pt-12 md:pt-24">
        <Reveal>
          <h1 className="max-w-3xl text-4xl font-bold md:text-7xl">
            Build a resume that gets you interviews.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Pick a template, fill in your story, and download a polished resume in
            ten minutes.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg">Create my resume</Button>
            <Button size="lg" variant="outline">See templates</Button>
          </div>
        </Reveal>
      </Section>

      <Section id="templates" className="bg-muted/50">
        <SectionHeading eyebrow="Templates" title="Designs recruiters actually read" />
        <div className="grid gap-6 md:grid-cols-3">
          {["Classic", "Modern", "Compact"].map((name, i) => (
            <Reveal key={name} delay={i * 0.08}>
              <Card hoverable>
                <CardContent>
                  <h3 className="text-xl font-semibold">{name}</h3>
                  <p className="mt-2 text-muted-foreground">
                    Clean sections, readable type, ATS-friendly.
                  </p>
                </CardContent>
              </Card>
            </Reveal>
          ))}
        </div>
      </Section>

      <Section id="signin">
        <Card className="mx-auto max-w-md">
          <CardContent className="space-y-5">
            <div>
              <h2 className="text-2xl font-semibold">Welcome back</h2>
              <p className="mt-1 text-muted-foreground">Sign in to continue your resume.</p>
            </div>
            <Input label="Email" type="email" placeholder="you@example.com" />
            <Input label="Password" type="password" placeholder="Your password" />
            <Button size="lg" className="w-full">Sign in</Button>
          </CardContent>
        </Card>
      </Section>
    </div>
  );
}
```

---

## How the generator uses this

1. The design brief step outputs a palette and two fonts.
2. The server converts the brief into new values for `:root` in `index.css` and the font `@import` line (a simple string replace, no AI needed for this part).
3. The model builds pages from `Section`, `Reveal`, `Button`, `Card`, `Input`, `Navbar` and adds new components only when needed.
4. Because every component reads from tokens, changing the brief changes the entire look, and nothing falls back to default blue.

Notes:
- Add `"paths": { "@/*": ["./src/*"] }` to `tsconfig.json` and the matching alias in `vite.config.ts` for the `@/` imports.
- Add 4-6 more components over time (Testimonial, PricingCard, FAQ accordion, Footer, Hero variants) so the model has more building blocks.
