import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

import { GoogleGenAI } from "@google/genai";

const SYSTEM = `You are Spark to Live Studio (Orgraai), an elite full-stack brand designer and expert frontend engineer building top-notch, production-grade web applications from plain-language user requests. Your output must never look like a generic template or default blue SaaS app.

Always reply with:
1. One or two short sentences describing what you built or changed.
2. The COMPLETE application as a single self-contained HTML document inside one \`\`\`html fenced block.

## DESIGN SYSTEM & AESTHETIC RULES
- Distinctive aesthetic (editorial, luxury-minimal, warm-organic, retro-tech, or clean SaaS with custom curated tone).
- Typography: Use real Google Fonts (e.g. Fraunces, Plus Jakarta Sans, Inter, Cormorant Garamond, Space Grotesk) loaded via Google Fonts link in <head>. Define --font-heading and --font-body.
- Colors: Define CSS variables in :root (background, foreground, primary, accent, muted, border, radius) and use semantic token classes (bg-background, text-foreground, bg-primary, text-primary-foreground, bg-accent, text-muted-foreground, border-border). NEVER use raw hardcoded color classes like bg-blue-600 or text-white.
- Spacing & Rhythm: Generous whitespace (section padding py-20 md:py-32, container max-w-6xl).
- Layout & Quality: Mobile-first responsive (375px, 768px, 1280px). One dominant H1 per page (text-4xl md:text-6xl). Zero horizontal scroll.
- Components & Blocks: Compose polished sections (Hero, Bento Features, Feature Split, Stats, Testimonials, Pricing, FAQ, CTABanner, Footer) with clean cards, soft shadows, hover lift, and focus rings.
- Forms & Controls: Inputs with clear labels, 48px height, focus-visible states, loading/error states, specific button action verbs ("Start building", "Sign in").
- Content & Copy: Real, specific copy tailored to the prompt. NEVER use lorem ipsum, "Your text here", or stock filler phrases like "cutting-edge" or "seamless".
- Accessibility: Semantic HTML, sufficient contrast, aria-labels on icon buttons.

## BACKEND & DATABASE SDK
A real Supabase-backed backend SDK is pre-injected globally as \`window.Orgraa\` for persistence across refreshes and devices:
- Auth: \`await window.Orgraa.auth.signUp({ email, password, name })\`, \`signIn\`, \`signOut\`, \`getUser()\`.
- Database: \`const col = window.Orgraa.db.collection("item_name")\`, \`col.list()\` or \`list({ mine: true })\`, \`col.create(data)\`, \`col.update(id, data)\`, \`col.remove(id)\`.
Always use \`window.Orgraa.auth\` for login/signup and \`window.Orgraa.db.collection(...)\` for data persistence. Do not use localStorage for app data.

## EDITING EXISTING APPS
When changing an existing app, return the whole updated file with targeted improvements while preserving working features and database collections.`;

type Msg = { role: "user" | "assistant"; content: string };

async function callGemini(messages: Msg[]): Promise<string> {
  const apiKey =
    process.env["GEMINI_API_KEY"] || process.env["LOVABLE_API_KEY"] || process.env["API_KEY"];
  if (!apiKey) {
    throw new Error(
      "AI is not configured. Please add your GEMINI_API_KEY in the Settings > Secrets panel.",
    );
  }

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  const contents = messages.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));

  try {
    const streamRes = await ai.models.generateContentStream({
      model: "gemini-4-neon",
      contents,
      config: {
        systemInstruction: SYSTEM,
      },
    });

    let text = "";
    for await (const chunk of streamRes) {
      if (chunk.text) text += chunk.text;
    }
    return text;
  } catch (err) {
    console.error("Gemini API error", err);
    const msg = err instanceof Error ? err.message : "AI generation failed.";
    if (/API_KEY_INVALID|PERMISSION_DENIED|403|400/i.test(msg)) {
      throw new Error(
        "Invalid or missing API key. Please check your GEMINI_API_KEY in the Settings > Secrets panel.",
      );
    }
    throw new Error(msg);
  }
}

export function extractHtml(text: string): { html: string | null; summary: string } {
  const m = text.match(/```html\s*([\s\S]*?)(```|$)/i);
  const html = m?.[1] ? m[1].trim() : null;
  const summary = (m ? text.slice(0, m.index) : text).trim() || "Updated the app.";
  return { html, summary };
}

export const generateApp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { projectId: string; prompt: string }) => {
    if (!input?.projectId || typeof input.prompt !== "string") throw new Error("Invalid input");
    const prompt = input.prompt.trim();
    if (!prompt || prompt.length > 8000) throw new Error("Prompt must be 1-8000 characters.");
    return { projectId: input.projectId, prompt };
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: project, error: pErr } = await supabase
      .from("projects")
      .select("id, code, name")
      .eq("id", data.projectId)
      .single();
    if (pErr || !project) throw new Error("Project not found.");

    await supabase
      .from("messages")
      .insert({ project_id: project.id, user_id: userId, role: "user", content: data.prompt });

    const { data: history } = await supabase
      .from("messages")
      .select("role, content")
      .eq("project_id", project.id)
      .order("created_at", { ascending: true })
      .limit(20);

    const msgs: Msg[] = (history ?? []).map((m) => ({
      role: m.role as Msg["role"],
      content: m.content,
    }));
    const last = msgs[msgs.length - 1];
    if (project.code && last) {
      last.content = `Current app code:\n\`\`\`html\n${project.code}\n\`\`\`\n\nRequest: ${last.content}`;
    }

    const text = await callGemini(msgs);
    const { html, summary } = extractHtml(text);

    await supabase
      .from("messages")
      .insert({ project_id: project.id, user_id: userId, role: "assistant", content: summary });
    const patch: { updated_at: string; code?: string; name?: string } = {
      updated_at: new Date().toISOString(),
    };
    if (html) patch.code = html;
    if (project.name === "Untitled app") patch.name = data.prompt.slice(0, 48);
    await supabase.from("projects").update(patch).eq("id", project.id);

    return { summary, code: html ?? project.code };
  });
