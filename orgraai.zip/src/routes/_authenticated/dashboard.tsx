import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash, faWindowMaximize, faCloud } from "@fortawesome/free-solid-svg-icons";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { AppHeader } from "@/components/AppHeader";

const projectsQuery = queryOptions({
  queryKey: ["projects"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("projects")
      .select("id, name, updated_at")
      .order("updated_at", { ascending: false });
    if (error) throw error;
    return data;
  },
});

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Your apps - Forge" },
      {
        name: "description",
        content: "Start a new AI-built app or continue one of your projects.",
      },
      { property: "og:title", content: "Your apps - Forge" },
      {
        property: "og:description",
        content: "Start a new AI-built app or continue one of your projects.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(projectsQuery),
  component: Dashboard,
});

const starterPrompts = [
  "A habit tracker with weekly streaks and a clean calendar view",
  "An AI-powered recipe generator with dietary filters and grocery lists",
  "A real-time crypto portfolio tracker with interactive charts and alerts",
  "A minimalist Kanban board with drag-and-drop tasks and due dates",
  "A SaaS invoice generator with PDF export and client management",
];

function Dashboard() {
  const { data: projects } = useSuspenseQuery(projectsQuery);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [placeholderText, setPlaceholderText] = useState(starterPrompts[0]);
  const [starterIndex, setStarterIndex] = useState(0);

  useEffect(() => {
    const pending = sessionStorage.getItem("pending_prompt");
    if (pending) {
      sessionStorage.removeItem("pending_prompt");
      setPrompt(pending);
    }
  }, []);

  useEffect(() => {
    if (prompt !== "") {
      setPlaceholderText("A web app that...");
      return;
    }

    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) {
      setPlaceholderText(starterPrompts[0]);
      return;
    }

    let currentPromptIdx = 0;
    let charIdx = 0;
    let isDeleting = false;
    let timeoutId: NodeJS.Timeout;

    function type() {
      const fullText = starterPrompts[currentPromptIdx];
      if (isDeleting) {
        charIdx--;
        setPlaceholderText(fullText.slice(0, charIdx));
        if (charIdx === 0) {
          isDeleting = false;
          currentPromptIdx = (currentPromptIdx + 1) % starterPrompts.length;
          timeoutId = setTimeout(type, 400);
          return;
        }
        timeoutId = setTimeout(type, 35);
      } else {
        charIdx++;
        setPlaceholderText(fullText.slice(0, charIdx));
        if (charIdx === fullText.length) {
          isDeleting = true;
          timeoutId = setTimeout(type, 2200);
          return;
        }
        timeoutId = setTimeout(type, 65);
      }
    }

    timeoutId = setTimeout(type, 400);
    return () => clearTimeout(timeoutId);
  }, [prompt]);

  async function start(): Promise<void> {
    if (!prompt.trim()) return;
    setBusy(true);
    const { data: userData } = await supabase.auth.getUser();
    const userId = userData?.user?.id;
    const { data, error } = await supabase
      .from("projects")
      .insert(userId ? { user_id: userId, name: prompt.trim().slice(0, 48) } : {})
      .select("id")
      .single();
    setBusy(false);
    if (error || !data) {
      toast.error(error?.message ?? "Could not create project");
      return;
    }
    navigate({ to: "/project/$id", params: { id: data.id }, search: { prompt: prompt.trim() } });
  }

  async function remove(id: string): Promise<void> {
    const { error } = await supabase.from("projects").delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    qc.invalidateQueries({ queryKey: ["projects"] });
  }

  function insertStarterPrompt() {
    setPrompt(starterPrompts[starterIndex % starterPrompts.length]);
    setStarterIndex((i) => i + 1);
  }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-4xl px-6 py-16">
        <h1 className="text-4xl font-bold tracking-tight">What do you want to build?</h1>
        <div className="mt-6 rounded-lg border bg-card p-3 shadow-sm">
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                start();
              }
            }}
            placeholder={placeholderText}
            className="min-h-24 resize-none border-0 bg-transparent text-base shadow-none focus-visible:ring-0 placeholder:text-muted-foreground/60 transition-colors"
          />
          <div className="flex items-center justify-between border-t border-border/50 pt-2.5 mt-2">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={insertStarterPrompt}
              className="h-8 gap-1.5 px-2.5 text-xs text-muted-foreground hover:text-foreground"
            >
              <span className="text-base font-bold">+</span> Example prompt
            </Button>
            <Button
              onClick={start}
              disabled={busy || !prompt.trim()}
              className="h-9 px-5 font-semibold"
            >
              {busy ? (
                <span className="flex items-center gap-2">
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                  Building...
                </span>
              ) : (
                "Build"
              )}
            </Button>
          </div>
        </div>

        <div className="mt-16 flex items-center justify-between">
          <h2 className="text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Your apps ({projects.length})
          </h2>
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <FontAwesomeIcon icon={faCloud} className="text-emerald-500" /> Saved to your account
          </span>
        </div>
        {projects.length === 0 ? (
          <p className="mt-4 text-muted-foreground">
            No apps yet. Describe one above to get started.
          </p>
        ) : (
          <ul className="mt-4 divide-y rounded-lg border bg-card">
            {projects.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-4 px-4 py-3">
                <Link
                  to="/project/$id"
                  params={{ id: p.id }}
                  className="flex min-w-0 items-center gap-3 hover:text-primary"
                >
                  <FontAwesomeIcon icon={faWindowMaximize} className="text-muted-foreground" />
                  <span className="truncate">{p.name}</span>
                </Link>
                <div className="flex shrink-0 items-center gap-3">
                  <span className="text-xs text-muted-foreground">
                    {new Date(p.updated_at).toLocaleDateString()}
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Delete app"
                    onClick={() => remove(p.id)}
                  >
                    <FontAwesomeIcon icon={faTrash} />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
}
