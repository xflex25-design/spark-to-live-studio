import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { isSupabaseConfigured } from "@/lib/supabase-ready";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/auth/callback")({
  head: () => ({
    meta: [
      { title: "Authenticating - Spark to Live Studio" },
      { name: "description", content: "Completing authentication..." },
    ],
  }),
  component: AuthCallbackPage,
});

function AuthCallbackPage() {
  const navigate = useNavigate();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    // 1. If opened in a popup window with opener, notify parent and close
    if (window.opener && !window.opener.closed) {
      try {
        window.opener.postMessage(
          {
            type: "OAUTH_AUTH_SUCCESS",
            source: "supabase_github",
            url: window.location.href,
            search: window.location.search,
            hash: window.location.hash,
          },
          "*",
        );
        setTimeout(() => {
          window.close();
        }, 300);
        return;
      } catch (e) {
        console.error("Failed to notify opener window:", e);
      }
    }

    // 2. If opened in the main window (direct redirect fallback)
    async function handleDirectCallback() {
      if (!isSupabaseConfigured()) {
        setErrorMsg("Supabase is not configured.");
        return;
      }

      const params = new URLSearchParams(window.location.search);
      const code = params.get("code");
      const error = params.get("error_description") || params.get("error");

      if (error) {
        setErrorMsg(error);
        return;
      }

      try {
        if (code) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
          if (exchangeError) {
            setErrorMsg(exchangeError.message);
            return;
          }
        } else if (window.location.hash) {
          const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));
          const access_token = hashParams.get("access_token");
          const refresh_token = hashParams.get("refresh_token");
          if (access_token && refresh_token) {
            const { error: sessionError } = await supabase.auth.setSession({
              access_token,
              refresh_token,
            });
            if (sessionError) {
              setErrorMsg(sessionError.message);
              return;
            }
          }
        }

        const { data } = await supabase.auth.getUser();
        if (data.user) {
          navigate({ to: "/dashboard", replace: true });
        } else {
          navigate({ to: "/auth", replace: true });
        }
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : "Authentication failed");
      }
    }

    handleDirectCallback();
  }, [navigate]);

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm rounded-xl border bg-card p-6 text-center shadow-lg sm:p-8">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        {errorMsg ? (
          <div className="mt-6">
            <h1 className="text-xl font-bold text-destructive">Authentication Error</h1>
            <p className="mt-2 text-sm text-muted-foreground">{errorMsg}</p>
            <button
              onClick={() => navigate({ to: "/auth", replace: true })}
              className="mt-6 inline-flex h-9 items-center justify-center rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground"
            >
              Back to Sign In
            </button>
          </div>
        ) : (
          <div className="mt-6">
            <div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            <h1 className="mt-4 text-lg font-bold text-foreground">Completing authentication</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Connecting your GitHub account and loading your workspace...
            </p>
          </div>
        )}
      </div>
    </main>
  );
}
