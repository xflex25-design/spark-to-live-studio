import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getSupabaseConfigError, isSupabaseConfigured } from "@/lib/supabase-ready";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in - Spark to Live Studio" },
      {
        name: "description",
        content: "Sign in or create an account to build and save your AI-generated apps.",
      },
      { property: "og:title", content: "Sign in - Spark to Live Studio" },
      {
        property: "og:description",
        content: "Sign in or create an account to build and save your AI-generated apps.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const githubSvg = (
  <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
    />
  </svg>
);

const googleSvg = (
  <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24">
    <path
      fill="#4285F4"
      d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"
    />
    <path
      fill="#FBBC05"
      d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"
    />
    <path
      fill="#EA4335"
      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
    />
  </svg>
);

function getAuthRedirectUrl(): string {
  return new URL("/auth", window.location.origin).toString();
}

function getAuthCallbackUrl(): string {
  return new URL("/auth/callback", window.location.origin).toString();
}

function openOAuthPopup(url: string): Window | null {
  const width = 600;
  const height = 700;
  const left = window.screenX + (window.outerWidth - width) / 2;
  const top = window.screenY + (window.outerHeight - height) / 2;
  return window.open(
    url,
    "supabase_oauth_popup",
    `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes,status=yes`,
  );
}

function formatAuthError(err: unknown): string {
  const message = err instanceof Error ? err.message : String(err);
  if (/invalid.*url/i.test(message)) {
    return "Invalid Supabase or Redirect URL. Verify VITE_SUPABASE_URL is https://<project-ref>.supabase.co and add this app's URL to Supabase Auth Redirect URLs.";
  }
  return message || "Authentication failed. Please try again.";
}

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isSupabaseConfigured()) return;

    supabase.auth
      .getUser()
      .then(({ data }) => {
        if (data.user) navigate({ to: "/dashboard", replace: true });
      })
      .catch(() => {
        // Handled when user submits the form
      });

    const { data: authSub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session) {
        toast.success("Signed in successfully!");
        navigate({ to: "/dashboard", replace: true });
      }
    });

    // Check if the current window arrived with OAuth query params
    const currentParams = new URLSearchParams(window.location.search);
    const code = currentParams.get("code");
    const errorParam = currentParams.get("error_description") || currentParams.get("error");

    if (errorParam) {
      toast.error(errorParam);
    } else if (code) {
      setBusy(true);
      supabase.auth.exchangeCodeForSession(code).then(({ error }) => {
        if (error) {
          toast.error(formatAuthError(error));
          setBusy(false);
        } else {
          toast.success("Signed in with GitHub successfully!");
          navigate({ to: "/dashboard", replace: true });
        }
      });
    }

    // Listen for postMessage from popup OAuth callback
    const handleOAuthMessage = async (event: MessageEvent) => {
      if (event.data?.type !== "OAUTH_AUTH_SUCCESS") return;

      setBusy(true);
      try {
        const { search, hash } = event.data as { search?: string; hash?: string };
        const searchParams = new URLSearchParams(search || "");
        const msgCode = searchParams.get("code");
        const msgError = searchParams.get("error_description") || searchParams.get("error");

        if (msgError) {
          toast.error(msgError);
          setBusy(false);
          return;
        }

        if (msgCode) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(msgCode);
          if (exchangeError) {
            toast.error(formatAuthError(exchangeError));
            setBusy(false);
            return;
          }
        } else if (hash) {
          const hashParams = new URLSearchParams(hash.replace(/^#/, ""));
          const access_token = hashParams.get("access_token");
          const refresh_token = hashParams.get("refresh_token");
          if (access_token && refresh_token) {
            const { error: sessionError } = await supabase.auth.setSession({
              access_token,
              refresh_token,
            });
            if (sessionError) {
              toast.error(formatAuthError(sessionError));
              setBusy(false);
              return;
            }
          }
        }

        const { data: userRes } = await supabase.auth.getUser();
        if (userRes.user) {
          toast.success("Signed in with GitHub successfully!");
          navigate({ to: "/dashboard", replace: true });
        } else {
          setBusy(false);
        }
      } catch (err) {
        toast.error(formatAuthError(err));
        setBusy(false);
      }
    };

    window.addEventListener("message", handleOAuthMessage);

    return () => {
      authSub.subscription.unsubscribe();
      window.removeEventListener("message", handleOAuthMessage);
    };
  }, [navigate]);

  async function submit(e: React.FormEvent): Promise<void> {
    e.preventDefault();
    const configError = getSupabaseConfigError();
    if (configError) {
      toast.error(configError);
      return;
    }

    setBusy(true);
    try {
      if (mode === "up") {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { emailRedirectTo: getAuthRedirectUrl() },
        });
        if (error) {
          toast.error(formatAuthError(error));
          return;
        }
        if (!data.session) {
          toast.success("Check your email to confirm your account.");
          return;
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (error) {
          toast.error(formatAuthError(error));
          return;
        }
      }
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(formatAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  async function socialGitHub(): Promise<void> {
    const configError = getSupabaseConfigError();
    if (configError) {
      toast.error(configError);
      return;
    }

    setBusy(true);
    try {
      const callbackUrl = getAuthCallbackUrl();
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: "github",
        options: {
          redirectTo: callbackUrl,
          scopes: "read:user user:email",
          skipBrowserRedirect: true,
        },
      });

      if (error) {
        toast.error(formatAuthError(error));
        setBusy(false);
        return;
      }

      if (!data?.url) {
        toast.error("Could not obtain GitHub authorization URL.");
        setBusy(false);
        return;
      }

      const popup = openOAuthPopup(data.url);
      if (!popup || popup.closed || typeof popup.closed === "undefined") {
        toast.info("Opening GitHub login in current tab...");
        window.location.href = data.url;
        return;
      }

      const timer = setInterval(() => {
        if (popup.closed) {
          clearInterval(timer);
          setBusy(false);
        }
      }, 600);
    } catch (err) {
      toast.error(formatAuthError(err));
      setBusy(false);
    }
  }

  async function socialGoogle(): Promise<void> {
    const configError = getSupabaseConfigError();
    if (configError) {
      toast.error(configError);
      return;
    }

    setBusy(true);
    try {
      const callbackUrl = getAuthCallbackUrl();
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: callbackUrl,
          skipBrowserRedirect: true,
        },
      });
      if (error) {
        toast.error(formatAuthError(error));
        setBusy(false);
        return;
      }

      if (!data?.url) {
        toast.error("Could not obtain Google authorization URL.");
        setBusy(false);
        return;
      }

      const popup = openOAuthPopup(data.url);
      if (!popup || popup.closed || typeof popup.closed === "undefined") {
        window.location.href = data.url;
        return;
      }

      const timer = setInterval(() => {
        if (popup.closed) {
          clearInterval(timer);
          setBusy(false);
        }
      }, 600);
    } catch (err) {
      toast.error(formatAuthError(err));
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-12">
      <section
        aria-labelledby="auth-heading"
        className="w-full max-w-sm rounded-xl border bg-card p-6 shadow-lg sm:p-8"
      >
        <header className="text-center">
          <div className="flex justify-center">
            <Link to="/" aria-label="Back to home">
              <Logo size="lg" />
            </Link>
          </div>
          <h1 id="auth-heading" className="mt-6 text-2xl font-bold text-foreground">
            {mode === "in" ? "Welcome back" : "Create your account"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {mode === "in"
              ? "Sign in to continue building your apps."
              : "Sign up to start building and saving your apps."}
          </p>
        </header>

        <div className="mt-6 flex flex-col gap-2.5">
          <Button
            type="button"
            variant="outline"
            className="h-10 w-full gap-2 border-border/80 hover:bg-accent hover:text-accent-foreground"
            disabled={busy}
            onClick={socialGitHub}
          >
            {githubSvg} Continue with GitHub
          </Button>
          <Button
            type="button"
            variant="outline"
            className="h-10 w-full gap-2 border-border/80 hover:bg-accent hover:text-accent-foreground"
            disabled={busy}
            onClick={socialGoogle}
          >
            {googleSvg} Continue with Google
          </Button>
        </div>

        <div className="relative my-6 flex items-center" role="separator">
          <div className="flex-1 border-t" />
          <span className="px-4 text-xs text-muted-foreground">or continue with email</span>
          <div className="flex-1 border-t" />
        </div>

        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              autoComplete={mode === "in" ? "current-password" : "new-password"}
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" disabled={busy} className="mt-2 h-10 w-full">
            {mode === "in" ? "Sign in" : "Sign up"}
          </Button>
        </form>

        <footer className="mt-6 text-center">
          <button
            type="button"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            onClick={() => setMode(mode === "in" ? "up" : "in")}
          >
            {mode === "in" ? "No account? Sign up" : "Have an account? Sign in"}
          </button>
        </footer>
      </section>
    </main>
  );
}
