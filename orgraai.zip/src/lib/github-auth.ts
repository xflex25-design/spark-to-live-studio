import { supabase } from "@/integrations/supabase/client";
import { getSupabaseConfigError } from "@/lib/supabase-ready";
import { toast } from "sonner";

export async function initiateGitHubOAuth(): Promise<Window | null> {
  const configError = getSupabaseConfigError();
  if (configError) {
    toast.error(configError);
    return null;
  }

  try {
    const callbackUrl = new URL("/auth/callback", window.location.origin).toString();
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: "github",
      options: {
        redirectTo: callbackUrl,
        scopes: "read:user user:email",
        skipBrowserRedirect: true,
      },
    });

    if (error) {
      toast.error(error.message);
      return null;
    }

    if (!data?.url) {
      toast.error("Could not obtain GitHub authorization URL.");
      return null;
    }

    const width = 600;
    const height = 700;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;
    const popup = window.open(
      data.url,
      "supabase_github_oauth",
      `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes,status=yes`,
    );

    if (!popup || popup.closed || typeof popup.closed === "undefined") {
      toast.info("Opening GitHub authorization in current tab...");
      window.location.href = data.url;
      return null;
    }

    return popup;
  } catch (err) {
    toast.error(err instanceof Error ? err.message : "Failed to initiate GitHub authorization.");
    return null;
  }
}
