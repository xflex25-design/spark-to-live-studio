import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faRightFromBracket, faGauge } from "@fortawesome/free-solid-svg-icons";
import { Menu } from "lucide-react";
import { useState, useEffect, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { isSupabaseConfigured } from "@/lib/supabase-ready";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { GitHubIcon } from "@/components/GitHubIcon";
import { initiateGitHubOAuth } from "@/lib/github-auth";
import { toast } from "sonner";

type UserProfile = {
  email?: string;
  name?: string;
  avatarUrl?: string;
  githubUser?: string;
};

export function AppHeader({ children }: { children?: ReactNode }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [githubBusy, setGithubBusy] = useState(false);

  function refreshUser() {
    if (!isSupabaseConfigured()) return;
    supabase.auth.getUser().then(({ data }) => {
      if (data?.user) {
        const meta = (data.user.user_metadata || {}) as Record<string, unknown>;
        setUser({
          email: data.user.email,
          name:
            (meta.full_name as string) ||
            (meta.name as string) ||
            data.user.email?.split("@")[0] ||
            "Builder",
          avatarUrl: (meta.avatar_url as string) || undefined,
          githubUser:
            (meta.user_name as string) || (meta.preferred_username as string) || undefined,
        });
      }
    });
  }

  useEffect(() => {
    refreshUser();

    function onOAuthMessage(e: MessageEvent) {
      if (e.data?.type === "OAUTH_AUTH_SUCCESS") {
        setGithubBusy(false);
        refreshUser();
        toast.success("Connected to GitHub successfully!");
      }
    }

    window.addEventListener("message", onOAuthMessage);
    return () => window.removeEventListener("message", onOAuthMessage);
  }, []);

  async function handleConnectGitHub() {
    setGithubBusy(true);
    const popup = await initiateGitHubOAuth();
    if (popup) {
      const timer = setInterval(() => {
        if (popup.closed) {
          clearInterval(timer);
          setGithubBusy(false);
        }
      }, 600);
    } else {
      setGithubBusy(false);
    }
  }

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    if (isSupabaseConfigured()) {
      await supabase.auth.signOut();
    }
    navigate({ to: "/auth", replace: true });
  }

  return (
    <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b bg-panel px-6 shadow-sm">
      <div className="flex min-w-0 items-center gap-6">
        <Link to="/dashboard" className="flex items-center">
          <Logo />
        </Link>
        {children}
      </div>

      {/* Desktop Navigation */}
      <div className="hidden md:flex items-center gap-3">
        {user && (
          <div className="flex items-center gap-2 rounded-full border bg-card/70 px-3 py-1 text-xs">
            {user.avatarUrl ? (
              <img
                src={user.avatarUrl}
                alt={user.name || "User"}
                className="h-5 w-5 rounded-full object-cover"
              />
            ) : (
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-secondary font-mono text-[10px] font-semibold text-foreground">
                {(user.name || "U").charAt(0).toUpperCase()}
              </span>
            )}
            <span className="max-w-[130px] truncate font-medium text-foreground">
              {user.githubUser ? `@${user.githubUser}` : user.name}
            </span>
            {user.githubUser && (
              <span className="rounded bg-accent px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground">
                GitHub
              </span>
            )}
          </div>
        )}
        {!user?.githubUser && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleConnectGitHub}
            disabled={githubBusy}
            className="gap-2 border-border/80 hover:bg-accent hover:text-accent-foreground cursor-pointer"
          >
            <GitHubIcon className="h-4 w-4" />
            {githubBusy ? "Connecting..." : "Connect to GitHub"}
          </Button>
        )}
        <Link to="/dashboard">
          <Button variant="ghost" size="sm" className="gap-2">
            <FontAwesomeIcon icon={faGauge} /> Dashboard
          </Button>
        </Link>
        <Button variant="outline" size="sm" onClick={signOut} className="gap-2">
          <FontAwesomeIcon icon={faRightFromBracket} /> Sign out
        </Button>
      </div>

      {/* Mobile Hamburger Menu on Right */}
      <div className="md:hidden">
        <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" aria-label="Open Navigation Menu">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[280px] sm:w-[320px] p-6">
            <div className="flex flex-col h-full justify-between">
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b pb-4">
                  <Logo />
                </div>
                {user && (
                  <div className="flex items-center gap-3 rounded-lg border bg-card p-3">
                    {user.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.name || "User"}
                        className="h-9 w-9 rounded-full object-cover"
                      />
                    ) : (
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary font-mono text-xs font-semibold text-foreground">
                        {(user.name || "U").charAt(0).toUpperCase()}
                      </span>
                    )}
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-foreground">{user.name}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {user.githubUser ? `@${user.githubUser}` : user.email}
                      </p>
                    </div>
                  </div>
                )}
                <nav className="flex flex-col gap-3">
                  <Link
                    to="/dashboard"
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium hover:bg-accent"
                  >
                    <FontAwesomeIcon icon={faGauge} className="w-4 h-4" /> Dashboard
                  </Link>

                  {user?.githubUser ? (
                    <div className="flex items-center gap-2.5 rounded-lg border bg-accent/40 px-3 py-2 text-xs">
                      <GitHubIcon className="h-4 w-4" />
                      <div className="min-w-0">
                        <p className="font-medium text-foreground">GitHub Connected</p>
                        <p className="font-mono text-[11px] text-muted-foreground">
                          @{user.githubUser}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-2.5 text-sm font-medium border-border/80 hover:bg-accent hover:text-accent-foreground cursor-pointer"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        handleConnectGitHub();
                      }}
                      disabled={githubBusy}
                    >
                      <GitHubIcon className="h-4 w-4" />
                      {githubBusy ? "Connecting..." : "Connect to GitHub"}
                    </Button>
                  )}
                </nav>
              </div>
              <div className="border-t pt-4">
                <Button
                  variant="destructive"
                  className="w-full gap-2"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    signOut();
                  }}
                >
                  <FontAwesomeIcon icon={faRightFromBracket} /> Sign out
                </Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
