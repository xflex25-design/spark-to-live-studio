import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { supabase } from '@/integrations/supabase/client';
import { linkImportedIdentity } from '@/lib/identity.functions';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/ui/button';

export const Route = createFileRoute('/auth/callback')({
  head: () => ({ meta: [{ title: 'Verify account — OrgraaAI' }, { name: 'description', content: 'Securely verify your OrgraaAI account.' }, { property: 'og:title', content: 'Verify account — OrgraaAI' }, { property: 'og:description', content: 'Securely verify your OrgraaAI account.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }] }),
  component: Callback,
});
function Callback() {
  const navigate = useNavigate();
  const linkIdentity = useServerFn(linkImportedIdentity);
  const [error, setError] = useState('');
  useEffect(() => {
    async function complete() {
      const params = new URLSearchParams(window.location.search);
      if (params.get('error_description')) throw new Error(params.get('error_description') ?? 'Verification failed');
      const code = params.get('code');
      if (code) { const { error } = await supabase.auth.exchangeCodeForSession(code); if (error) throw error; }
      const { data } = await supabase.auth.getUser();
      if (!data.user) { await navigate({ to: '/auth', replace: true }); return; }
      await linkIdentity();
      if (params.get('setup') === '1' || window.location.hash.includes('type=recovery')) window.location.replace('/auth?setup=1');
      else await navigate({ to: '/dashboard', replace: true });
    }
    complete().catch(e => setError(e instanceof Error ? e.message : 'Could not verify account.'));
  }, [navigate, linkIdentity]);
  return <main className="flex min-h-screen items-center justify-center p-6"><div className="max-w-sm text-center"><Logo size="lg" /><h1 className="mt-6 text-xl">{error ? 'Verification failed' : 'Verifying your account…'}</h1>{error && <><p className="mt-3 text-sm text-muted-foreground">{error}</p><Button className="mt-6" onClick={() => navigate({ to: '/auth' })}>Back to sign in</Button></>}</div></main>;
}