import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable';
import { linkImportedIdentity } from '@/lib/identity.functions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Logo } from '@/components/Logo';

export const Route = createFileRoute('/auth')({
  head: () => ({ meta: [{ title: 'Sign in — OrgraaAI' }, { name: 'description', content: 'Sign in to create and save your OrgraaAI apps.' }, { property: 'og:title', content: 'Sign in — OrgraaAI' }, { property: 'og:description', content: 'Sign in to create and save your OrgraaAI apps.' }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const linkIdentity = useServerFn(linkImportedIdentity);
  const [mode, setMode] = useState<'in' | 'up' | 'recover' | 'setup'>('in');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  useEffect(() => {
    if (new URLSearchParams(window.location.search).get('setup') === '1' || window.location.hash.includes('type=recovery')) { setMode('setup'); return; }
    supabase.auth.getUser().then(({ data }) => { if (data.user) navigate({ to: '/dashboard', replace: true }); });
  }, [navigate]);
  async function finish() { await linkIdentity(); await navigate({ to: '/dashboard', replace: true }); }
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setNotice('');
    try {
      const callback = `${window.location.origin}/auth/callback?setup=1`;
      if (mode === 'recover') {
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: callback });
        if (error) throw error;
        setNotice('Check your email for a secure link to choose your password.');
      } else if (mode === 'setup') {
        const { error } = await supabase.auth.updateUser({ password });
        if (error) throw error;
        await finish();
      } else if (mode === 'up') {
        const { data, error } = await supabase.auth.signUp({ email: email.trim(), password, options: { emailRedirectTo: callback } });
        if (error) throw error;
        if (data.session) await finish(); else setNotice('Check your email to verify your account.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        await finish();
      }
    } catch (error) { toast.error(error instanceof Error ? error.message : 'Sign-in failed.'); }
    finally { setBusy(false); }
  }
  async function google() {
    setBusy(true);
    try {
      const result = await lovable.auth.signInWithOAuth('google', { redirect_uri: `${window.location.origin}/auth/callback` });
      if (result.error) throw result.error;
      if (!result.redirected) await finish();
    } catch (error) { toast.error(error instanceof Error ? error.message : 'Could not sign in with Google.'); }
    finally { setBusy(false); }
  }
  const title = mode === 'in' ? 'Welcome back' : mode === 'up' ? 'Create your account' : mode === 'setup' ? 'Choose your password' : 'Reset your password';
  return <main className="flex min-h-screen items-center justify-center px-4 py-12"><section className="w-full max-w-sm rounded-lg border bg-card p-6 sm:p-8"><header className="text-center"><Link to="/" className="inline-flex"><Logo size="lg" /></Link><h1 className="mt-6 text-2xl font-bold">{title}</h1></header>{(mode === 'in' || mode === 'up') && <><Button variant="outline" className="mt-6 w-full" disabled={busy} onClick={google}>Continue with Google</Button><div className="my-6 flex items-center gap-3 text-xs text-muted-foreground"><div className="flex-1 border-t" />or continue with email<div className="flex-1 border-t" /></div></>}<form onSubmit={submit} className="mt-6 grid gap-4">{mode !== 'setup' && <div className="grid gap-2"><Label htmlFor="email">Email</Label><Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} required autoComplete="email" /></div>}{mode !== 'recover' && <div className="grid gap-2"><Label htmlFor="password">Password</Label><Input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={6} autoComplete={mode === 'in' ? 'current-password' : 'new-password'} /></div>}<Button type="submit" disabled={busy}>{busy ? 'Please wait…' : mode === 'in' ? 'Sign in' : mode === 'up' ? 'Sign up' : mode === 'setup' ? 'Save password' : 'Send email link'}</Button>{notice && <p role="status" className="text-sm text-success">{notice}</p>}</form><footer className="mt-5 flex flex-col items-center gap-1">{mode !== 'setup' && <Button variant="link" onClick={() => setMode(mode === 'in' ? 'up' : 'in')}>{mode === 'in' ? 'No account? Sign up' : 'Back to sign in'}</Button>}{mode === 'in' && <Button variant="link" onClick={() => setMode('recover')}>Forgot password or returning after migration?</Button>}</footer></section></main>;
}