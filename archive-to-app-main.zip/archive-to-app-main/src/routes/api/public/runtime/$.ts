import { createFileRoute } from '@tanstack/react-router';

async function handle({ request }: { request: Request }) {
  const { handleAppRuntimeRequest } = await import('@/lib/app-runtime.server');
  return handleAppRuntimeRequest(request);
}
export const Route = createFileRoute('/api/public/runtime/$')({ server: { handlers: { GET: handle, POST: handle, PATCH: handle, DELETE: handle, OPTIONS: handle } } });