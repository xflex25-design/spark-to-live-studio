import { createFileRoute } from '@tanstack/react-router';

async function handle({ request }: { request: Request }) {
  const { handleAppRuntimeRequest } = await import('@/lib/app-runtime.server');
  return handleAppRuntimeRequest(request);
}
// Legacy path preserved for original SDK callers; caller verification is inside the handler.
export const Route = createFileRoute('/api/runtime/$')({ server: { handlers: { GET: handle, POST: handle, PATCH: handle, DELETE: handle, OPTIONS: handle } } });