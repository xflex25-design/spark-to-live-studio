import { createFileRoute } from "@tanstack/react-router";
import Home from "@/components/Home";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OrgraaAI - Build apps by describing them" },
      {
        name: "description",
        content:
          "Type what you want. OrgraaAI writes the code with AI and runs it in a live preview.",
      },
      { property: "og:title", content: "OrgraaAI - Build apps by describing them" },
      {
        property: "og:description",
        content:
          "Type what you want. OrgraaAI writes the code with AI and runs it in a live preview.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});
