import { Link, useNavigate } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { Menu, LogOut, LayoutDashboard } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import { Logo } from './Logo';

export function AppHeader({ children }: { children?: ReactNode }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  async function signOut() {
    await qc.cancelQueries();
    await supabase.auth.signOut();
    qc.clear();
    await navigate({ to: '/auth', replace: true });
  }
  const actions = <><Button asChild variant="ghost"><Link to="/dashboard"><LayoutDashboard /> Dashboard</Link></Button><Button variant="outline" onClick={signOut}><LogOut /> Sign out</Button></>;
  return <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b bg-panel px-4 sm:px-6"><div className="flex min-w-0 items-center gap-4"><Link to="/dashboard"><Logo /></Link>{children}</div><nav className="hidden items-center gap-3 md:flex">{actions}</nav><div className="md:hidden"><Sheet open={open} onOpenChange={setOpen}><SheetTrigger asChild><Button variant="outline" size="icon" aria-label="Open navigation menu"><Menu /></Button></SheetTrigger><SheetContent><SheetTitle>OrgraaAI</SheetTitle><nav className="mt-8 flex flex-col gap-4">{actions}</nav></SheetContent></Sheet></div></header>;
}