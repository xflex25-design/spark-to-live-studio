import logo from '@/assets/orgraai-logo.asset.json';

export function Logo({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  return <img src={logo.url} alt="OrgraaAI" className={`${size === 'lg' ? 'h-10' : size === 'sm' ? 'h-7' : 'h-8'} w-auto max-w-full object-contain`} />;
}