export function isSupabaseConfigured() { return true; }
export function getSupabaseConfigError(): string | null { return null; }