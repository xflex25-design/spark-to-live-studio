import { createServerFn } from '@tanstack/react-start';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

export const linkImportedIdentity = createServerFn({ method: 'POST' })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.auth.getUser();
    if (error || !data.user?.email_confirmed_at || !data.user.email) throw new Error('Verify your email before accessing imported projects.');
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const { data: identity } = await supabaseAdmin.from('migration_identities').select('source_user_id,auth_user_id').eq('email', data.user.email.toLowerCase()).maybeSingle();
    if (!identity) return { linked: false };
    if (identity.auth_user_id && identity.auth_user_id !== data.user.id) throw new Error('This profile is already linked to another account.');
    const { error: claimError } = await supabaseAdmin.from('migration_identities').update({ auth_user_id: data.user.id }).eq('source_user_id', identity.source_user_id).or(`auth_user_id.is.null,auth_user_id.eq.${data.user.id}`).select().single();
    if (claimError) throw new Error('Could not securely link your imported account.');
    const originalId = identity.source_user_id;
    if (/^[0-9a-f-]{36}$/i.test(originalId)) {
      const p = await supabaseAdmin.from('projects').update({ user_id: data.user.id }).eq('user_id', originalId);
      const m = await supabaseAdmin.from('messages').update({ user_id: data.user.id }).eq('user_id', originalId);
      const r = await supabaseAdmin.from('app_records').update({ owner_id: data.user.id }).eq('owner_id', originalId);
      if (p.error || m.error || r.error) throw new Error('Could not restore all imported records. Please try again.');
    }
    return { linked: true };
  });