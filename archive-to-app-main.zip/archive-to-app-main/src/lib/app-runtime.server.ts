import { createClient } from '@supabase/supabase-js';
import type { Database, Json } from '@/integrations/supabase/types';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Cache-Control': 'no-store' };
function reply(body: unknown, status = 200) { return Response.json(body, { status, headers: cors }); }
export async function handleAppRuntimeRequest(request: Request): Promise<Response> {
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  const url = new URL(request.url);
  const [projectId, resource, action, recordId] = url.pathname.replace(/^\/api\/(?:public\/)?runtime\//, '').split('/').map(decodeURIComponent);
  if (!projectId || !/^[0-9a-f-]{36}$/i.test(projectId)) return reply({ error: 'Invalid project.' }, 400);
  const serverUrl = process.env['SUPABASE_URL'];
  const key = process.env['SUPABASE_PUBLISHABLE_KEY'];
  if (!serverUrl || !key) return reply({ error: 'App service is unavailable.' }, 503);
  const token = request.headers.get('Authorization')?.replace(/^Bearer /, '');
  const client = createClient<Database>(serverUrl, key, { auth: { persistSession: false, autoRefreshToken: false }, global: { fetch: (input, init) => {
    const headers = new Headers(init?.headers);
    if (headers.get('Authorization') === `Bearer ${key}` && key.startsWith('sb_')) headers.delete('Authorization');
    headers.set('apikey', key);
    return fetch(input, { ...init, headers });
  }, headers: token ? { Authorization: `Bearer ${token}` } : {} } });
  try {
    const body = request.method === 'GET' || request.method === 'DELETE' ? {} : await request.json() as Record<string, unknown>;
    if (resource === 'auth' && (action === 'signup' || action === 'login') && request.method === 'POST') {
      if (typeof body['email'] !== 'string' || typeof body['password'] !== 'string') return reply({ error: 'Email and password are required.' }, 400);
      const result = action === 'signup'
        ? await client.auth.signUp({ email: body['email'], password: body['password'], options: { emailRedirectTo: `${url.origin}/auth/callback?setup=1`, data: { name: typeof body['name'] === 'string' ? body['name'].slice(0, 120) : '' } } })
        : await client.auth.signInWithPassword({ email: body['email'], password: body['password'] });
      if (result.error) return reply({ error: result.error.message }, 400);
      if (!result.data.session) return reply({ error: 'Check your email to verify your account, then sign in.' }, 401);
      return reply({ user: { id: result.data.user?.id, email: result.data.user?.email, name: result.data.user?.user_metadata['name'] ?? '' }, token: result.data.session.access_token });
    }
    if (!token) return reply({ error: 'Sign in required.' }, 401);
    const { data: auth, error: authError } = await client.auth.getUser(token);
    if (authError || !auth.user?.email_confirmed_at) return reply({ error: 'A verified account is required.' }, 401);
    const user = auth.user;
    // Privileged membership establishment follows verified caller authentication.
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const { data: project } = await supabaseAdmin.from('projects').select('id').eq('id', projectId).maybeSingle();
    if (!project) return reply({ error: 'Project not found.' }, 404);
    const { error: memberError } = await supabaseAdmin.from('app_memberships').upsert({ project_id: projectId, user_id: user.id, name: typeof user.user_metadata['name'] === 'string' ? user.user_metadata['name'] : '' });
    if (memberError) throw memberError;
    if (resource === 'auth') {
      if (action === 'me' && request.method === 'GET') return reply({ user: { id: user.id, email: user.email, name: user.user_metadata['name'] ?? '' } });
      if (action === 'logout' && request.method === 'POST') { await client.auth.signOut(); return reply({ ok: true }); }
      return reply({ error: 'Unknown account action.' }, 404);
    }
    if (resource !== 'db' || !action || !/^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/.test(action)) return reply({ error: 'Invalid collection.' }, 400);
    if (request.method === 'GET' && !recordId) {
      const limit = Math.max(1, Math.min(200, Number(url.searchParams.get('limit')) || 100));
      const { data, error } = await client.from('app_records').select('id,collection,owner_id,data,created_at,updated_at').eq('project_id', projectId).eq('collection', action).eq('owner_id', user.id).order('created_at', { ascending: false }).limit(limit);
      if (error) throw error;
      return reply({ records: data });
    }
    if (request.method === 'DELETE' && recordId) {
      const { error } = await client.from('app_records').delete().eq('project_id', projectId).eq('collection', action).eq('id', recordId).eq('owner_id', user.id);
      if (error) throw error;
      return reply({ ok: true });
    }
    const payload = body['data'] ?? body;
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return reply({ error: 'Record must be an object.' }, 400);
    if (JSON.stringify(payload).length > 100000) return reply({ error: 'Record is too large.' }, 413);
    if (request.method === 'POST' && !recordId) {
      const { data, error } = await client.from('app_records').insert({ project_id: projectId, collection: action, owner_id: user.id, data: payload as Json }).select().single();
      if (error) throw error;
      return reply({ record: data }, 201);
    }
    if (request.method === 'PATCH' && recordId) {
      const { data: existing, error: readError } = await client.from('app_records').select('data').eq('project_id', projectId).eq('collection', action).eq('id', recordId).eq('owner_id', user.id).single();
      if (readError || !existing) return reply({ error: 'Record not found.' }, 404);
      const old = existing.data && typeof existing.data === 'object' && !Array.isArray(existing.data) ? existing.data : {};
      const { data, error } = await client.from('app_records').update({ data: { ...old, ...payload } as Json, updated_at: new Date().toISOString() }).eq('project_id', projectId).eq('collection', action).eq('id', recordId).eq('owner_id', user.id).select().single();
      if (error) throw error;
      return reply({ record: data });
    }
    return reply({ error: 'Unknown action.' }, 404);
  } catch (error) { console.error('Generated app request failed', error); return reply({ error: 'The app request could not be completed.' }, 500); }
}