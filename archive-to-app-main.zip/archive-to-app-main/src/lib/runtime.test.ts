import { describe, it, expect } from 'vitest';
import { buildOrgraaSdkScript, injectOrgraaSdk } from './runtime-sdk';

describe('Generated app SDK', () => {
  it('uses the public runtime endpoint for the selected project', () => {
    const script = buildOrgraaSdkScript('550e8400-e29b-41d4-a716-446655440000', 'https://example.com/');
    expect(script).toContain('https://example.com/api/public/runtime/550e8400-e29b-41d4-a716-446655440000');
  });
  it('escapes project configuration to prevent closing the script', () => {
    const script = buildOrgraaSdkScript('</script><script>bad()</script>', 'https://example.com');
    expect(script).not.toContain('</script><script>bad()');
  });
  it('leaves empty generated code empty', () => {
    expect(injectOrgraaSdk('', 'project', 'https://example.com')).toBe('');
  });
});