# Migration tasks
- [x] Preserve original pages and design
- [x] Migrate schema, authentication and generated-app runtime to Cloud
- [x] Verify signed-in project CRUD and private access
- [x] Verify AI generation with preserved Gemini key
- [ ] Import existing application records and users (requires exports)
- [ ] Complete publishing/cutover and acceptance of unsupported GitHub sign-in
- [ ] Verify real Google sign-in and imported-user email/password flow (requires user interaction and exports)
