<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

People get working websites and apps they can put to use.

## Metric

Generated apps rendered in a live preview each week
