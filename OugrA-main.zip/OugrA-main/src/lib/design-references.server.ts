import fs from "node:fs/promises";
import path from "node:path";
import type { Part } from "@google/genai";

const REFERENCE_IMAGE_FILES = [
  "IMG-20261119-WA0092_1__0a54a44b.jpg",
  "IMG-20261119-WA0093_1__0000e31b.jpg",
  "IMG-20261119-WA0088_507e49a3.jpg",
  "IMG-20261119-WA0089_fcbd02aa.jpg",
  "IMG-20261119-WA0090_1__c10da683.jpg",
  "IMG-20261119-WA0091_ab725e90.jpg",
  "IMG-20261119-WA0087_1__3d2ee209.jpg",
] as const;

export const DESIGN_REFERENCE_INSTRUCTION =
  "The images attached above are hidden visual design references for UI quality, layout composition, spacing, typography hierarchy, navbar/hero framing, card elevation, and CTA contrast. Adapt the aesthetic direction (light minimal SaaS, dark sleek studio, editorial brand showcase, or structured portal) that best fits the user's app. Never copy brand names, logos, or sample text from these screenshots.";

let cachedPartsPromise: Promise<Part[]> | null = null;

async function readFirstAvailable(filename: string): Promise<Buffer | null> {
  const candidates = [
    path.resolve(process.cwd(), "public/assets/aistudio", filename),
    path.resolve(process.cwd(), ".output/public/assets/aistudio", filename),
  ];

  for (const filePath of candidates) {
    try {
      return await fs.readFile(filePath);
    } catch {
      // Try next candidate path
    }
  }
  return null;
}

async function loadDesignReferenceParts(): Promise<Part[]> {
  const buffers = await Promise.all(REFERENCE_IMAGE_FILES.map((file) => readFirstAvailable(file)));
  const parts: Part[] = [];

  for (const buf of buffers) {
    if (!buf) continue;
    parts.push({
      inlineData: {
        mimeType: "image/jpeg",
        data: buf.toString("base64"),
      },
    });
  }

  return parts;
}

export function getDesignReferenceParts(): Promise<Part[]> {
  if (!cachedPartsPromise) {
    cachedPartsPromise = loadDesignReferenceParts().catch((err) => {
      console.warn("[DesignReferences] Failed to load reference images:", err);
      cachedPartsPromise = null;
      return [];
    });
  }
  return cachedPartsPromise;
}
