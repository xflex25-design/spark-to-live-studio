import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import type { EmailOtpType } from "@supabase/supabase-js";
import { Loader2, MailCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { getSupabaseConfigError, isSupabaseConfigured } from "@/lib/supabase-ready";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in - Spark to Live Studio" },
      {
        name: "description",
        content: "Sign in or create an account to build and save your AI-generated apps.",
      },
      { property: "og:title", content: "Sign in - Spark to Live Studio" },
      {
        property: "og:description",
        content: "Sign in or create an account to build and save your AI-generated apps.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const googleSvg = (
  <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24">
    <path
      fill="#4285F4"
      d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"
    />
    <path
      fill="#FBBC05"
      d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"
    />
    <path
      fill="#EA4335"
      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
    />
  </svg>
);

const EMAIL_OTP_TYPES = new Set<EmailOtpType>([
  "signup",
  "invite",
  "magiclink",
  "recovery",
  "email_change",
  "email",
]);

function getAuthRedirectUrl(): string {
  return new URL("/auth", window.location.origin).toString();
}

function formatAuthError(err: unknown): string {
  const message = err instanceof Error ? err.message : String(err);
  if (/invalid.*url/i.test(message)) {
    return "Invalid Supabase or Redirect URL. Verify VITE_SUPABASE_URL is https://<project-ref>.supabase.co and add this app's URL to Supabase Auth Redirect URLs.";
  }
  return message || "Authentication failed. Please try again.";
}

type AuthMode = "in" | "up" | "otp";

type PendingConfirmation = {
  email: string;
  flow: "signup" | "otp";
};

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<AuthMode>("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [verifyingCallback, setVerifyingCallback] = useState(false);
  const [pendingConfirmation, setPendingConfirmation] = useState<PendingConfirmation | null>(null);
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = setTimeout(() => setResendCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearTimeout(timer);
  }, [resendCooldown]);

  useEffect(() => {
    if (!isSupabaseConfigured()) return;
    let active = true;

    async function handleAuthInit() {
      const searchParams = new URLSearchParams(window.location.search);
      const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ""));

      const callbackError =
        searchParams.get("error_description") ||
        hashParams.get("error_description") ||
        searchParams.get("error") ||
        hashParams.get("error");

      if (callbackError) {
        toast.error(formatAuthError(callbackError));
        window.history.replaceState({}, "", "/auth");
      }

      const code = searchParams.get("code");
      const tokenHash = searchParams.get("token_hash");
      const rawType = searchParams.get("type");
      const otpType =
        rawType && EMAIL_OTP_TYPES.has(rawType as EmailOtpType)
          ? (rawType as EmailOtpType)
          : undefined;

      if (code || (tokenHash && otpType)) {
        if (active) setVerifyingCallback(true);
        try {
          const { data: sessionData } = await supabase.auth.getSession();
          if (!sessionData.session) {
            if (code) {
              const { error } = await supabase.auth.exchangeCodeForSession(code);
              if (error) throw error;
            } else if (tokenHash && otpType) {
              const { error } = await supabase.auth.verifyOtp({
                token_hash: tokenHash,
                type: otpType,
              });
              if (error) throw error;
            }
          }
          window.history.replaceState({}, "", "/auth");
          toast.success("Email confirmed. Welcome!");
          if (active) navigate({ to: "/dashboard", replace: true });
          return;
        } catch (err) {
          window.history.replaceState({}, "", "/auth");
          toast.error(formatAuthError(err));
        } finally {
          if (active) setVerifyingCallback(false);
        }
      }

      try {
        const { data } = await supabase.auth.getUser();
        if (data.user && active) {
          navigate({ to: "/dashboard", replace: true });
        }
      } catch {
        // Handled when the user submits the form
      }
    }

    void handleAuthInit();

    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if ((event === "SIGNED_IN" || event === "USER_UPDATED") && session) {
        navigate({ to: "/dashboard", replace: true });
      }
    });

    return () => {
      active = false;
      data.subscription.unsubscribe();
    };
  }, [navigate]);

  async function submit(e: React.FormEvent): Promise<void> {
    e.preventDefault();
    const configError = getSupabaseConfigError();
    if (configError) {
      toast.error(configError);
      return;
    }

    const cleanEmail = email.trim();
    if (!cleanEmail) return;

    setBusy(true);
    try {
      if (mode === "otp") {
        const { error } = await supabase.auth.signInWithOtp({
          email: cleanEmail,
          options: {
            emailRedirectTo: getAuthRedirectUrl(),
            shouldCreateUser: true,
          },
        });
        if (error) {
          toast.error(formatAuthError(error));
          return;
        }
        setPendingConfirmation({ email: cleanEmail, flow: "otp" });
        setOtpCode("");
        setResendCooldown(30);
        toast.success("Confirmation link sent. Check your inbox.");
        return;
      }

      if (mode === "up") {
        const { data, error } = await supabase.auth.signUp({
          email: cleanEmail,
          password,
          options: { emailRedirectTo: getAuthRedirectUrl() },
        });
        if (error) {
          toast.error(formatAuthError(error));
          return;
        }
        if (!data.session) {
          setPendingConfirmation({ email: cleanEmail, flow: "signup" });
          setOtpCode("");
          setResendCooldown(30);
          toast.success("Check your email to confirm your account.");
          return;
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });
        if (error) {
          if (/email not confirmed/i.test(error.message)) {
            setPendingConfirmation({ email: cleanEmail, flow: "signup" });
            setOtpCode("");
            toast.error("Your email is not confirmed yet. Check your inbox or resend the link.");
            return;
          }
          toast.error(formatAuthError(error));
          return;
        }
      }
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(formatAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  async function verifyCodeSubmit(e: React.FormEvent): Promise<void> {
    e.preventDefault();
    if (!pendingConfirmation) return;
    const token = otpCode.trim();
    if (!token) return;

    setBusy(true);
    try {
      const { error } = await supabase.auth.verifyOtp({
        email: pendingConfirmation.email,
        token,
        type: pendingConfirmation.flow === "signup" ? "signup" : "email",
      });
      if (error) {
        toast.error(formatAuthError(error));
        return;
      }
      toast.success("Email confirmed. Signed in!");
      navigate({ to: "/dashboard", replace: true });
    } catch (err) {
      toast.error(formatAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  async function resendConfirmation(): Promise<void> {
    if (!pendingConfirmation || resendCooldown > 0) return;

    setBusy(true);
    try {
      if (pendingConfirmation.flow === "signup") {
        const { error } = await supabase.auth.resend({
          type: "signup",
          email: pendingConfirmation.email,
          options: { emailRedirectTo: getAuthRedirectUrl() },
        });
        if (error) {
          toast.error(formatAuthError(error));
          return;
        }
      } else {
        const { error } = await supabase.auth.signInWithOtp({
          email: pendingConfirmation.email,
          options: {
            emailRedirectTo: getAuthRedirectUrl(),
            shouldCreateUser: true,
          },
        });
        if (error) {
          toast.error(formatAuthError(error));
          return;
        }
      }
      setResendCooldown(30);
      toast.success(`Confirmation email resent to ${pendingConfirmation.email}.`);
    } catch (err) {
      toast.error(formatAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  async function socialGoogle(): Promise<void> {
    const configError = getSupabaseConfigError();
    if (configError) {
      toast.error(configError);
      return;
    }

    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo: getAuthRedirectUrl() },
      });
      if (error) {
        toast.error(formatAuthError(error));
      }
    } catch (err) {
      toast.error(formatAuthError(err));
    } finally {
      setBusy(false);
    }
  }

  if (verifyingCallback) {
    return (
      <main className="flex min-h-screen items-center justify-center px-4 py-12">
        <section className="w-full max-w-sm rounded-xl border bg-card p-6 text-center shadow-lg sm:p-8">
          <div className="flex justify-center">
            <Logo size="lg" />
          </div>
          <div className="mt-8 flex flex-col items-center gap-3">
            <Loader2 className="h-6 w-6 animate-spin text-foreground" />
            <h1 className="text-lg font-semibold text-foreground">Confirming your email</h1>
            <p className="text-sm text-muted-foreground">
              Verifying your confirmation link and signing you in...
            </p>
          </div>
        </section>
      </main>
    );
  }

  if (pendingConfirmation) {
    return (
      <main className="flex min-h-screen items-center justify-center px-4 py-12">
        <section
          aria-labelledby="confirm-email-heading"
          className="w-full max-w-sm rounded-xl border bg-card p-6 shadow-lg sm:p-8"
        >
          <header className="text-center">
            <div className="flex justify-center">
              <Link to="/" aria-label="Back to home">
                <Logo size="lg" />
              </Link>
            </div>
            <div className="mx-auto mt-6 flex h-11 w-11 items-center justify-center rounded-full border bg-secondary">
              <MailCheck className="h-5 w-5 text-foreground" />
            </div>
            <h1 id="confirm-email-heading" className="mt-4 text-2xl font-bold text-foreground">
              Check your email
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              We sent a confirmation link to{" "}
              <span className="font-medium text-foreground">{pendingConfirmation.email}</span>.
              Click the link in your inbox to confirm your email and sign in.
            </p>
          </header>

          <form onSubmit={verifyCodeSubmit} className="mt-6 grid gap-3">
            <div className="grid gap-2">
              <Label htmlFor="otp-code">Or enter confirmation code</Label>
              <Input
                id="otp-code"
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="Enter 6-digit code"
                maxLength={10}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={busy || !otpCode.trim()} className="h-10 w-full">
              {busy ? "Verifying..." : "Verify & sign in"}
            </Button>
          </form>

          <div className="mt-4 grid gap-2">
            <Button
              type="button"
              variant="outline"
              disabled={busy || resendCooldown > 0}
              onClick={resendConfirmation}
              className="h-10 w-full"
            >
              {resendCooldown > 0
                ? `Resend email in ${resendCooldown}s`
                : "Resend confirmation email"}
            </Button>
          </div>

          <footer className="mt-6 text-center">
            <button
              type="button"
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              onClick={() => {
                setPendingConfirmation(null);
                setOtpCode("");
              }}
            >
              Back to sign in
            </button>
          </footer>
        </section>
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-12">
      <section
        aria-labelledby="auth-heading"
        className="w-full max-w-sm rounded-xl border bg-card p-6 shadow-lg sm:p-8"
      >
        <header className="text-center">
          <div className="flex justify-center">
            <Link to="/" aria-label="Back to home">
              <Logo size="lg" />
            </Link>
          </div>
          <h1 id="auth-heading" className="mt-6 text-2xl font-bold text-foreground">
            {mode === "in"
              ? "Welcome back"
              : mode === "up"
                ? "Create your account"
                : "Sign in with email"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {mode === "in"
              ? "Sign in to continue building your apps."
              : mode === "up"
                ? "Sign up and confirm your email to start building."
                : "We will send a confirmation link and code to your email."}
          </p>
        </header>

        <div className="mt-6">
          <Button
            type="button"
            variant="outline"
            className="h-10 w-full gap-2"
            onClick={socialGoogle}
          >
            {googleSvg} Continue with Google
          </Button>
        </div>

        <div className="relative my-6 flex items-center" role="separator">
          <div className="flex-1 border-t" />
          <span className="px-4 text-xs text-muted-foreground">or continue with email</span>
          <div className="flex-1 border-t" />
        </div>

        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          {mode !== "otp" && (
            <div className="grid gap-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                autoComplete={mode === "in" ? "current-password" : "new-password"}
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          )}
          <Button type="submit" disabled={busy} className="mt-2 h-10 w-full">
            {busy
              ? "Please wait..."
              : mode === "in"
                ? "Sign in"
                : mode === "up"
                  ? "Sign up"
                  : "Send confirmation email"}
          </Button>
        </form>

        <footer className="mt-6 flex flex-col items-center gap-2 text-center">
          <button
            type="button"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            onClick={() => setMode(mode === "otp" ? "in" : "otp")}
          >
            {mode === "otp"
              ? "Sign in with password instead"
              : "Sign in with email confirmation link"}
          </button>
          <button
            type="button"
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            onClick={() => setMode(mode === "up" ? "in" : "up")}
          >
            {mode === "up" ? "Have an account? Sign in" : "No account? Sign up"}
          </button>
        </footer>
      </section>
    </main>
  );
}
