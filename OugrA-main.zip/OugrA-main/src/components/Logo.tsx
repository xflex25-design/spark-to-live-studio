interface LogoProps {
  size?: "sm" | "md" | "lg";
}

const sizeClasses = {
  sm: "h-5",
  md: "h-6",
  lg: "h-7",
} as const;

const textSizeClasses = {
  sm: "text-sm",
  md: "text-base",
  lg: "text-lg",
} as const;

export function Logo({ size = "md" }: LogoProps) {
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap">
      <img
        src="/assets/orgla-ai-logo.png"
        alt=""
        className={`${sizeClasses[size]} w-auto shrink-0 object-contain`}
      />
      <span className={`${textSizeClasses[size]} font-semibold tracking-tight text-foreground`}>
        orgla ai
      </span>
    </span>
  );
}
