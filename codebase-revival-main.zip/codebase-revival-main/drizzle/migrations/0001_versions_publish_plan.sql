ALTER TABLE public.projects ADD COLUMN is_public boolean NOT NULL DEFAULT false;
ALTER TABLE public.messages ADD COLUMN kind text NOT NULL DEFAULT 'chat';

GRANT SELECT ON public.projects TO anon;
CREATE POLICY "public projects readable" ON public.projects FOR SELECT TO anon, authenticated USING (is_public = true);

CREATE TABLE public.project_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid(),
  code text NOT NULL,
  label text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.project_versions TO authenticated;
GRANT ALL ON public.project_versions TO service_role;
ALTER TABLE public.project_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own versions select" ON public.project_versions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own versions insert" ON public.project_versions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.projects p WHERE p.id = project_id AND p.user_id = auth.uid()));
CREATE POLICY "own versions delete" ON public.project_versions FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX project_versions_idx ON public.project_versions(project_id, created_at DESC);