export type Template = { title: string; blurb: string; style: string; prompt: string };

export const TEMPLATES: Template[] = [
  {
    title: "Coffee shop site",
    blurb: "Menu, opening hours and online pre-orders",
    style: "editorial",
    prompt:
      "A website for a neighbourhood specialty coffee shop: hero with a warm photo-style gradient, menu with categories and prices, opening hours, location, and a pre-order form that saves orders.",
  },
  {
    title: "Habit tracker",
    blurb: "Daily check-ins with streaks",
    style: "minimal",
    prompt:
      "A habit tracker where users sign up, add habits, check them off daily, and see weekly streaks on a calendar grid. Data is saved per user.",
  },
  {
    title: "SaaS landing page",
    blurb: "Hero, features, pricing, FAQ",
    style: "bold",
    prompt:
      "A landing page for an invoicing tool for freelancers: hero with product mockup, feature grid, 3-tier pricing, testimonials, FAQ and a waitlist form that saves emails.",
  },
  {
    title: "Portfolio",
    blurb: "Projects gallery and contact",
    style: "dark",
    prompt:
      "A personal portfolio for a product designer: intro, filterable project gallery with case-study modals, about section, and a contact form that saves messages.",
  },
  {
    title: "Recipe book",
    blurb: "Save and search recipes",
    style: "playful",
    prompt:
      "A recipe book app: users sign in, add recipes with ingredients and steps, search and filter by tag, and mark favourites.",
  },
  {
    title: "Event RSVP",
    blurb: "Invite page with guest list",
    style: "editorial",
    prompt:
      "An elegant event invitation page for a wedding with schedule, venue map section, and an RSVP form that saves guests, plus a guest list view for signed-in hosts.",
  },
];

export const STYLE_OPTIONS = [
  { value: "auto", label: "Auto style" },
  { value: "minimal", label: "Minimal" },
  { value: "bold", label: "Bold" },
  { value: "playful", label: "Playful" },
  { value: "editorial", label: "Editorial" },
  { value: "dark", label: "Dark tech" },
] as const;
