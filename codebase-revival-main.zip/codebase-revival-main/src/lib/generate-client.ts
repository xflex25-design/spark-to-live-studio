import { supabase } from "@/integrations/supabase/client";

export type GenerateEvent =
  | { type: "status"; text: string }
  | { type: "delta"; text: string }
  | { type: "done"; summary: string; code: string; kind: string }
  | { type: "error"; message: string };

export type GenerateInput = {
  projectId: string;
  prompt: string;
  mode: "build" | "plan" | "fix";
  style: string;
  image: string | null;
};

/** Streams generation progress from the server, calling onEvent for each step. */
export async function streamGenerate(
  input: GenerateInput,
  onEvent: (e: GenerateEvent) => void,
): Promise<void> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("Please sign in again.");
  const res = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(input),
  });
  if (!res.ok || !res.body) throw new Error((await res.text()) || "Generation failed.");
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let nl: number;
    while ((nl = buf.indexOf("\n")) !== -1) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (line) onEvent(JSON.parse(line) as GenerateEvent);
    }
  }
}

/** Reads an image file as a data URL, shrinking large images so uploads stay small. */
export async function fileToDataUrl(file: File, maxSide = 1600): Promise<string> {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    await new Promise<void>((ok, fail) => {
      img.onload = () => ok();
      img.onerror = () => fail(new Error("Could not read that image."));
      img.src = url;
    });
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    canvas.getContext("2d")?.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.85);
  } finally {
    URL.revokeObjectURL(url);
  }
}
