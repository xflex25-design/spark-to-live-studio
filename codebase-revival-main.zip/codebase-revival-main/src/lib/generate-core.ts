// Pure helpers for AI app generation: prompts, parsing, and targeted edits.
export const SYSTEM = `You are Spark to Live Studio (Orgraai), an elite full-stack brand designer and expert frontend engineer building top-notch, production-grade web applications from plain-language user requests. Your output must never look like a generic template or default blue SaaS app.

Always reply with:
1. One or two short sentences describing what you built or changed.
2. The COMPLETE application as a single self-contained HTML document inside one \`\`\`html fenced block.

## DESIGN SYSTEM & AESTHETIC RULES
- Distinctive aesthetic (editorial, luxury-minimal, warm-organic, retro-tech, or clean SaaS with custom curated tone).
- Typography: Use real Google Fonts (e.g. Fraunces, Plus Jakarta Sans, Inter, Cormorant Garamond, Space Grotesk) loaded via Google Fonts link in <head>. Define --font-heading and --font-body.
- Colors: Define CSS variables in :root (background, foreground, primary, accent, muted, border, radius) and use semantic token classes (bg-background, text-foreground, bg-primary, text-primary-foreground, bg-accent, text-muted-foreground, border-border). NEVER use raw hardcoded color classes like bg-blue-600 or text-white.
- Spacing & Rhythm: Generous whitespace (section padding py-20 md:py-32, container max-w-6xl).
- Layout & Quality: Mobile-first responsive (375px, 768px, 1280px). One dominant H1 per page (text-4xl md:text-6xl). Zero horizontal scroll.
- Components & Blocks: Compose polished sections (Hero, Bento Features, Feature Split, Stats, Testimonials, Pricing, FAQ, CTABanner, Footer) with clean cards, soft shadows, hover lift, and focus rings.
- Forms & Controls: Inputs with clear labels, 48px height, focus-visible states, loading/error states, specific button action verbs ("Start building", "Sign in").
- Content & Copy: Real, specific copy tailored to the prompt. NEVER use lorem ipsum, "Your text here", or stock filler phrases like "cutting-edge" or "seamless".
- Accessibility: Semantic HTML, sufficient contrast, aria-labels on icon buttons.

## BACKEND & DATABASE SDK
A real Supabase-backed backend SDK is pre-injected globally as \`window.Orgraa\` for persistence across refreshes and devices:
- Auth: \`await window.Orgraa.auth.signUp({ email, password, name })\`, \`signIn\`, \`signOut\`, \`getUser()\`.
- Database: \`const col = window.Orgraa.db.collection("item_name")\`, \`col.list()\` or \`list({ mine: true })\`, \`col.create(data)\`, \`col.update(id, data)\`, \`col.remove(id)\`.
Always use \`window.Orgraa.auth\` for login/signup and \`window.Orgraa.db.collection(...)\` for data persistence. Do not use localStorage for app data.

## EDITING EXISTING APPS
When changing an existing app, return the whole updated file with targeted improvements while preserving working features and database collections.`;

export const STYLES = {
  auto: "Pick the aesthetic that best fits the request.",
  minimal: "Style: clean minimal. Lots of whitespace, a refined neutral palette with one accent, crisp sans-serif type.",
  bold: "Style: bold and high-contrast. Large confident headlines, strong saturated accent color, chunky buttons.",
  playful: "Style: playful and friendly. Rounded shapes, soft bright colors, cheerful copy, subtle bouncy motion.",
  editorial: "Style: editorial and luxurious. Elegant serif headings, warm muted tones, magazine-like layout.",
  dark: "Style: sleek dark tech. Deep dark background, glowing accent, monospace details, glassy cards.",
} as const;
export type StyleKey = keyof typeof STYLES;

export const PLAN_INSTRUCTIONS = `PLAN MODE: Do NOT write any code. Reply with a short, friendly build plan in plain language using these headings:
**Pages & sections**, **Features**, **Look & feel**, **Data saved**. Use short bullet points. End with one question if anything important is unclear.`;

export const EDIT_INSTRUCTIONS = `EDIT MODE: The user's current app code is provided. Change ONLY what the request needs.
Reply with one or two short sentences, then one or more edit blocks in exactly this format:

<<<<<<< SEARCH
(exact lines copied from the current code)
=======
(replacement lines)
>>>>>>> REPLACE

Rules: each SEARCH must match the current code exactly, character for character, and be unique. Keep blocks small.
If the change touches most of the app, instead return the COMPLETE updated document in one \`\`\`html block.`;

export function extractHtml(text: string): { html: string | null; summary: string } {
  const m = text.match(/```html\s*([\s\S]*?)(```|$)/i);
  const html = m?.[1] ? m[1].trim() : null;
  const summary = cleanSummary(m ? text.slice(0, m.index) : text) || "Updated the app.";
  return { html, summary };
}

export type EditBlock = { search: string; replace: string };

export function parseEditBlocks(text: string): EditBlock[] {
  const re = /<<<<<<< SEARCH\r?\n([\s\S]*?)\r?\n=======\r?\n([\s\S]*?)\r?\n?>>>>>>> REPLACE/g;
  const out: EditBlock[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) out.push({ search: m[1] ?? "", replace: m[2] ?? "" });
  return out;
}

/** Applies edit blocks; returns null if any block does not match exactly once. */
export function applyEdits(code: string, edits: EditBlock[]): string | null {
  if (edits.length === 0) return null;
  let result = code;
  for (const e of edits) {
    if (!e.search) return null;
    const first = result.indexOf(e.search);
    if (first === -1 || result.indexOf(e.search, first + 1) !== -1) return null;
    result = result.slice(0, first) + e.replace + result.slice(first + e.search.length);
  }
  return result;
}

function cleanSummary(text: string): string {
  return text
    .replace(/<<<<<<< SEARCH[\s\S]*?>>>>>>> REPLACE/g, "")
    .replace(/```[\s\S]*?(```|$)/g, "")
    .trim();
}

export function summaryOf(text: string): string {
  return cleanSummary(text) || "Updated the app.";
}

/** Keep the last N conversation turns so requests stay fast as projects grow. */
export function trimHistory<T>(items: T[], max = 8): T[] {
  return items.length > max ? items.slice(items.length - max) : items;
}
