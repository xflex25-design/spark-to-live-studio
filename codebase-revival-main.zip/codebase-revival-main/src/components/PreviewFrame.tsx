import { useEffect, useState } from "react";
import { injectOrgraaSdk } from "@/lib/runtime-sdk";
import { cn } from "@/lib/utils";

export type Device = "desktop" | "tablet" | "phone";
export const DEVICE_WIDTH: Record<Device, string> = {
  desktop: "100%",
  tablet: "768px",
  phone: "390px",
};

/** Renders generated app code in a sandboxed frame with the built-in backend SDK. */
export function PreviewFrame({
  code,
  projectId,
  device = "desktop",
  reloadKey = 0,
  className,
}: {
  code: string;
  projectId: string;
  device?: Device;
  reloadKey?: number;
  className?: string;
}) {
  const tokenKey = `orgraa_app_token:${projectId}`;
  const [token, setToken] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setToken(localStorage.getItem(tokenKey));
    setReady(true);
    function onMessage(e: MessageEvent) {
      const p = e.data as { type?: string; projectId?: string; token?: string | null } | null;
      if (!p || p.type !== "orgraa-runtime-token" || p.projectId !== projectId) return;
      if (p.token) localStorage.setItem(tokenKey, p.token);
      else localStorage.removeItem(tokenKey);
      setToken(p.token ?? null);
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [projectId, tokenKey]);

  if (!ready) return null;
  const html = injectOrgraaSdk(code, projectId, window.location.origin, token);

  return (
    <div className={cn("flex h-full w-full justify-center overflow-auto", className)}>
      <iframe
        key={reloadKey}
        title="App preview"
        srcDoc={html}
        sandbox="allow-scripts allow-forms allow-modals allow-popups"
        style={{ width: DEVICE_WIDTH[device] }}
        className={cn(
          "h-full max-w-full bg-background transition-[width] duration-300",
          device !== "desktop" && "my-4 rounded-xl border shadow-lg",
        )}
      />
    </div>
  );
}
