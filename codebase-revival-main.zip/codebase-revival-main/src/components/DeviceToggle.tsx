import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faDesktop, faMobileScreen, faTabletScreenButton } from "@fortawesome/free-solid-svg-icons";
import type { Device } from "@/components/PreviewFrame";
import { cn } from "@/lib/utils";

const OPTIONS: { value: Device; label: string; icon: typeof faDesktop }[] = [
  { value: "desktop", label: "Desktop", icon: faDesktop },
  { value: "tablet", label: "Tablet", icon: faTabletScreenButton },
  { value: "phone", label: "Phone", icon: faMobileScreen },
];

export function DeviceToggle({ value, onChange }: { value: Device; onChange: (d: Device) => void }) {
  return (
    <div className="inline-flex rounded-md border bg-card p-0.5" role="group" aria-label="Preview size">
      {OPTIONS.map((o) => (
        <button
          key={o.value}
          type="button"
          aria-label={o.label}
          aria-pressed={value === o.value}
          title={o.label}
          onClick={() => onChange(o.value)}
          className={cn(
            "inline-flex h-7 w-8 items-center justify-center rounded text-xs transition-colors",
            value === o.value ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground",
          )}
        >
          <FontAwesomeIcon icon={o.icon} />
        </button>
      ))}
    </div>
  );
}
