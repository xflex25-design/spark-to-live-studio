import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import {
  GatewayError,
  PaymentRequiredError,
  RateLimitError,
  streamResponse,
} from "@lovable.dev/ai-gateway";
import type { Database } from "@/integrations/supabase/types";
import {
  EDIT_INSTRUCTIONS,
  PLAN_INSTRUCTIONS,
  STYLES,
  SYSTEM,
  applyEdits,
  extractHtml,
  parseEditBlocks,
  summaryOf,
  trimHistory,
  type StyleKey,
} from "@/lib/generate-core";

type Body = {
  projectId: string;
  prompt: string;
  mode?: "build" | "plan" | "fix";
  style?: string;
  image?: string | null;
};

type Event =
  | { type: "status"; text: string }
  | { type: "delta"; text: string }
  | { type: "done"; summary: string; code: string; kind: string }
  | { type: "error"; message: string };

function userClient(token: string) {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("Backend is not configured.");
  return createClient<Database>(url, key, {
    global: {
      headers: { Authorization: `Bearer ${token}` },
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
  });
}

function friendlyError(err: unknown): string {
  if (err instanceof PaymentRequiredError) return "AI credits are used up. Add credits to keep building.";
  if (err instanceof RateLimitError) return "Too many requests right now. Please wait a moment and try again.";
  if (err instanceof GatewayError) return "AI generation failed. Please try again.";
  return err instanceof Error ? err.message : "Something went wrong.";
}

type InputMsg = {
  role: "user" | "assistant";
  content: string | Array<{ type: "input_text"; text: string } | { type: "input_image"; image_url: string }>;
};

async function runModel(
  instructions: string,
  input: InputMsg[],
  onDelta: (t: string) => void,
): Promise<string> {
  const stream = await streamResponse({
    model: "openai/gpt-6-astra",
    instructions,
    input: input as never,
  });
  let text = "";
  for await (const event of stream) {
    if (event.type === "response.output_text.delta") {
      text += event.delta;
      onDelta(event.delta);
    }
  }
  return text;
}

export const Route = createFileRoute("/api/generate")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const auth = request.headers.get("authorization") ?? "";
        const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
        if (token.split(".").length !== 3) return new Response("Unauthorized", { status: 401 });
        const supabase = userClient(token);
        const { data: userData, error: userErr } = await supabase.auth.getUser(token);
        if (userErr || !userData.user) return new Response("Unauthorized", { status: 401 });
        const userId = userData.user.id;

        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return new Response("Invalid body", { status: 400 });
        }
        const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
        if (!body.projectId || !prompt || prompt.length > 8000) {
          return new Response("Prompt must be 1-8000 characters.", { status: 400 });
        }
        const mode = body.mode === "plan" || body.mode === "fix" ? body.mode : "build";
        const style: StyleKey = body.style && body.style in STYLES ? (body.style as StyleKey) : "auto";
        const image =
          typeof body.image === "string" && body.image.startsWith("data:image/") && body.image.length < 6_000_000
            ? body.image
            : null;

        const { data: project, error: pErr } = await supabase
          .from("projects")
          .select("id, code, name, user_id")
          .eq("id", body.projectId)
          .single();
        if (pErr || !project || project.user_id !== userId) {
          return new Response("Project not found.", { status: 404 });
        }

        const enc = new TextEncoder();
        const stream = new ReadableStream<Uint8Array>({
          async start(controller) {
            const send = (e: Event) => controller.enqueue(enc.encode(JSON.stringify(e) + "\n"));
            try {
              await supabase.from("messages").insert({
                project_id: project.id,
                user_id: userId,
                role: "user",
                content: prompt,
                kind: mode === "fix" ? "fix" : "chat",
              });

              const { data: history } = await supabase
                .from("messages")
                .select("role, content")
                .eq("project_id", project.id)
                .order("created_at", { ascending: true })
                .limit(200);
              const msgs: InputMsg[] = trimHistory(history ?? [], 8).map((m) => ({
                role: m.role === "assistant" ? "assistant" : "user",
                content: m.content,
              }));
              // Conversation must start with a user turn.
              while (msgs.length && msgs[0]?.role !== "user") msgs.shift();

              const hasCode = Boolean(project.code);
              const editing = hasCode && mode !== "plan";
              let lastText = prompt;
              if (editing) {
                lastText = `Current app code:\n\`\`\`html\n${project.code}\n\`\`\`\n\nRequest: ${prompt}`;
              } else if (hasCode && mode === "plan") {
                lastText = `The app already exists (code omitted). Plan this change: ${prompt}`;
              }
              const lastContent: InputMsg["content"] = image
                ? [
                    { type: "input_text", text: lastText + "\n\n(The attached image is a design reference: match its layout, colors and feel.)" },
                    { type: "input_image", image_url: image },
                  ]
                : lastText;
              if (msgs.length) msgs[msgs.length - 1] = { role: "user", content: lastContent };
              else msgs.push({ role: "user", content: lastContent });

              const instructions = [
                SYSTEM,
                STYLES[style],
                mode === "plan" ? PLAN_INSTRUCTIONS : editing ? EDIT_INSTRUCTIONS : "",
              ]
                .filter(Boolean)
                .join("\n\n");

              send({
                type: "status",
                text: mode === "plan" ? "Planning your app" : editing ? "Reading your app and planning changes" : "Designing layout and writing code",
              });
              const text = await runModel(instructions, msgs, (d) => send({ type: "delta", text: d }));

              let code = project.code;
              let summary = summaryOf(text);
              let kind = mode === "plan" ? "plan" : "chat";

              if (mode !== "plan") {
                send({ type: "status", text: "Applying changes" });
                const full = extractHtml(text);
                if (full.html) {
                  code = full.html;
                } else if (editing) {
                  const applied = applyEdits(project.code, parseEditBlocks(text));
                  if (applied !== null) {
                    code = applied;
                  } else {
                    send({ type: "status", text: "Edits didn't line up, rewriting the full app" });
                    const retry = await runModel(
                      SYSTEM + "\n\n" + STYLES[style],
                      [{ role: "user", content: `Current app code:\n\`\`\`html\n${project.code}\n\`\`\`\n\nRequest: ${prompt}\n\nReturn the COMPLETE updated document.` }],
                      (d) => send({ type: "delta", text: d }),
                    );
                    const r = extractHtml(retry);
                    if (r.html) code = r.html;
                    summary = r.summary;
                  }
                }
                if (code === project.code && mode !== "fix") kind = "chat";
              }

              await supabase.from("messages").insert({
                project_id: project.id,
                user_id: userId,
                role: "assistant",
                content: summary,
                kind,
              });

              const patch: { updated_at: string; code?: string; name?: string } = {
                updated_at: new Date().toISOString(),
              };
              if (code !== project.code) {
                patch.code = code;
                await supabase.from("project_versions").insert({
                  project_id: project.id,
                  user_id: userId,
                  code,
                  label: prompt.slice(0, 80),
                });
              }
              if (project.name === "Untitled app") patch.name = prompt.slice(0, 48);
              await supabase.from("projects").update(patch).eq("id", project.id);

              send({ type: "done", summary, code, kind });
            } catch (err) {
              console.error("generate failed", err);
              send({ type: "error", message: friendlyError(err) });
            } finally {
              controller.close();
            }
          },
        });

        return new Response(stream, {
          headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store" },
        });
      },
    },
  },
});
