import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faRotateRight } from "@fortawesome/free-solid-svg-icons";
import { supabase } from "@/integrations/supabase/client";
import { PreviewFrame, type Device } from "@/components/PreviewFrame";
import { DeviceToggle } from "@/components/DeviceToggle";
import { Button } from "@/components/ui/button";

const previewQuery = (id: string) =>
  queryOptions({
    queryKey: ["project", id, "preview"],
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("id, name, code").eq("id", id).single();
      if (error) throw error;
      return data;
    },
  });

export const Route = createFileRoute("/_authenticated/preview/$id")({
  head: () => ({
    meta: [
      { title: "Full-page preview - Orgraai" },
      { name: "description", content: "See your AI-built app full screen." },
      { property: "og:title", content: "Full-page preview - Orgraai" },
      { property: "og:description", content: "See your AI-built app full screen." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(previewQuery(params.id)),
  component: FullPreview,
});

function FullPreview() {
  const { id } = Route.useParams();
  const { data } = useSuspenseQuery(previewQuery(id));
  const [device, setDevice] = useState<Device>("desktop");
  const [reload, setReload] = useState(0);

  return (
    <div className="flex h-dvh flex-col bg-panel">
      <div className="flex h-11 shrink-0 items-center justify-between gap-2 border-b px-2">
        <Link to="/project/$id" params={{ id }}>
          <Button variant="ghost" size="sm" className="gap-2">
            <FontAwesomeIcon icon={faArrowLeft} /> <span className="hidden sm:inline">Back to builder</span>
          </Button>
        </Link>
        <span className="truncate text-sm text-muted-foreground">{data.name}</span>
        <div className="flex items-center gap-1">
          <div className="hidden sm:block">
            <DeviceToggle value={device} onChange={setDevice} />
          </div>
          <Button variant="ghost" size="icon" aria-label="Reload preview" onClick={() => setReload((k) => k + 1)}>
            <FontAwesomeIcon icon={faRotateRight} />
          </Button>
        </div>
      </div>
      <div className="min-h-0 flex-1">
        {data.code ? (
          <PreviewFrame code={data.code} projectId={id} device={device} reloadKey={reload} />
        ) : (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            This app hasn't been built yet.
          </div>
        )}
      </div>
    </div>
  );
}
