import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faArrowUp,
  faCode,
  faDisplay,
  faRotateRight,
  faCopy,
  faCubes,
  faSpinner,
  faExpand,
  faClockRotateLeft,
  faGlobe,
  faImage,
  faXmark,
  faWandMagicSparkles,
  faTriangleExclamation,
  faCheck,
  faComments,
} from "@fortawesome/free-solid-svg-icons";
import { supabase } from "@/integrations/supabase/client";
import { streamGenerate, fileToDataUrl, type GenerateInput } from "@/lib/generate-client";
import { STYLE_OPTIONS } from "@/lib/templates";
import { PreviewFrame, type Device } from "@/components/PreviewFrame";
import { DeviceToggle } from "@/components/DeviceToggle";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { AppHeader } from "@/components/AppHeader";
import { cn } from "@/lib/utils";

const projectQuery = (id: string) =>
  queryOptions({
    queryKey: ["project", id],
    queryFn: async () => {
      const [p, m] = await Promise.all([
        supabase.from("projects").select("id, name, code, is_public").eq("id", id).single(),
        supabase
          .from("messages")
          .select("id, role, content, kind, created_at")
          .eq("project_id", id)
          .order("created_at"),
      ]);
      if (p.error) throw p.error;
      if (m.error) throw m.error;
      return { project: p.data, messages: m.data };
    },
  });

const versionsQuery = (id: string) =>
  queryOptions({
    queryKey: ["versions", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("project_versions")
        .select("id, label, code, created_at")
        .eq("project_id", id)
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data;
    },
  });

type Search = { prompt?: string; style?: string; plan?: boolean };

export const Route = createFileRoute("/_authenticated/project/$id")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(typeof s["prompt"] === "string" ? { prompt: s["prompt"] } : {}),
    ...(typeof s["style"] === "string" ? { style: s["style"] } : {}),
    ...(s["plan"] === true || s["plan"] === "true" ? { plan: true } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Builder - Orgraai" },
      { name: "description", content: "Chat with Orgraai to build your app and see it live." },
      { property: "og:title", content: "Builder - Orgraai" },
      { property: "og:description", content: "Chat with Orgraai to build your app and see it live." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(projectQuery(params.id)),
  component: Builder,
});

type ChatMsg = { id: string; role: string; content: string; kind?: string };

/** Text shown while streaming: everything before code/edit blocks begin. */
function streamedSummary(text: string): string {
  const cut = text.search(/```|<<<<<<< SEARCH/);
  return (cut === -1 ? text : text.slice(0, cut)).trim();
}

function Builder() {
  const { id } = Route.useParams();
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const { data } = useSuspenseQuery(projectQuery(id));
  const qc = useQueryClient();

  const [pending, setPending] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [steps, setSteps] = useState<string[]>([]);
  const [streamText, setStreamText] = useState("");
  const [tab, setTab] = useState<"preview" | "code">("preview");
  const [mobilePane, setMobilePane] = useState<"chat" | "preview">("chat");
  const [device, setDevice] = useState<Device>("desktop");
  const [frameKey, setFrameKey] = useState(0);
  const [style, setStyle] = useState<string>(search.style ?? "auto");
  const [planFirst, setPlanFirst] = useState<boolean>(search.plan ?? false);
  const [image, setImage] = useState<string | null>(null);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [versionsOpen, setVersionsOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const autoFixUsed = useRef(false);
  const busyRef = useRef(false);
  const sent = useRef(false);
  const bottom = useRef<HTMLDivElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  const messages: ChatMsg[] = [...data.messages, ...pending];
  const code = data.project.code;
  const lastMsg = data.messages[data.messages.length - 1];
  const showBuildPlan = !busy && lastMsg?.role === "assistant" && lastMsg.kind === "plan";

  async function run(prompt: string, mode: GenerateInput["mode"], opts?: { auto?: boolean }) {
    if (!prompt.trim() || busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setSteps([]);
    setStreamText("");
    setPreviewError(null);
    if (!opts?.auto) autoFixUsed.current = false;
    setPending([{ id: "pending", role: "user", content: prompt, kind: mode === "fix" ? "fix" : "chat" }]);
    const sentImage = mode === "fix" ? null : image;
    setImage(null);
    let changed = false;
    try {
      await streamGenerate({ projectId: id, prompt, mode, style, image: sentImage }, (e) => {
        if (e.type === "status") setSteps((s) => [...s, e.text]);
        else if (e.type === "delta") setStreamText((t) => t + e.text);
        else if (e.type === "done") changed = e.code !== code;
        else if (e.type === "error") throw new Error(e.message);
      });
      await qc.invalidateQueries({ queryKey: ["project", id] });
      qc.invalidateQueries({ queryKey: ["projects"] });
      qc.invalidateQueries({ queryKey: ["versions", id] });
      if (changed) {
        setTab("preview");
        setFrameKey((k) => k + 1);
        setMobilePane("preview");
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Generation failed");
      await qc.invalidateQueries({ queryKey: ["project", id] });
    } finally {
      setPending([]);
      setStreamText("");
      setSteps([]);
      busyRef.current = false;
      setBusy(false);
    }
  }

  function send(text: string) {
    const prompt = text.trim();
    if (!prompt) return;
    setInput("");
    void run(prompt, planFirst ? "plan" : "build");
  }

  function fixError(message: string, auto = false) {
    if (auto) autoFixUsed.current = true;
    setPreviewError(null);
    void run(`The app shows this error in the preview, please fix it: ${message}`, "fix", { auto });
  }

  // Preview errors: auto-fix once per request, then offer a button.
  useEffect(() => {
    function onMessage(e: MessageEvent) {
      const p = e.data as { type?: string; projectId?: string; message?: string } | null;
      if (!p || p.type !== "orgraa-preview-error" || p.projectId !== id || !p.message) return;
      if (busyRef.current) return;
      if (!autoFixUsed.current) {
        toast.message("Found an error in your app, fixing it automatically");
        fixError(p.message, true);
      } else {
        setPreviewError(p.message);
      }
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, style]);

  useEffect(() => {
    if (search.prompt && !sent.current) {
      sent.current = true;
      const p = search.prompt;
      navigate({ search: {}, replace: true });
      void run(p, search.plan ? "plan" : "build");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, busy, streamText.length > 0, steps.length]);

  async function onPickImage(file: File | undefined) {
    if (!file) return;
    if (!file.type.startsWith("image/")) return toast.error("Please choose an image file.");
    try {
      setImage(await fileToDataUrl(file));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not read that image.");
    }
  }

  const live = streamedSummary(streamText);
  const codeLines = streamText.length > live.length ? streamText.slice(live.length).split("\n").length : 0;

  const chatPane = (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4">
        {messages.length === 0 && !busy && (
          <p className="text-sm text-muted-foreground">Describe the app you want to build.</p>
        )}
        {messages.map((m) =>
          m.role === "user" ? (
            <div
              key={m.id}
              className={cn(
                "ml-8 whitespace-pre-wrap rounded-lg px-3 py-2 text-sm",
                m.kind === "fix" ? "border border-dashed text-muted-foreground" : "bg-bubble text-bubble-foreground",
              )}
            >
              {m.kind === "fix" && <FontAwesomeIcon icon={faWandMagicSparkles} className="mr-2" />}
              {m.content}
            </div>
          ) : (
            <div key={m.id} className="flex gap-3 text-sm">
              <span className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded bg-primary text-primary-foreground">
                <FontAwesomeIcon icon={faCubes} className="h-3 w-3" />
              </span>
              <div className="min-w-0 flex-1">
                {m.kind === "plan" && (
                  <p className="mb-1 text-xs font-medium uppercase tracking-wider text-primary">Plan</p>
                )}
                <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
              </div>
            </div>
          ),
        )}
        {showBuildPlan && (
          <div className="flex gap-2 pl-9">
            <Button size="sm" onClick={() => void run("Build the plan above.", "build")}>
              <FontAwesomeIcon icon={faCheck} /> Build this plan
            </Button>
          </div>
        )}
        {busy && (
          <div className="flex gap-3 text-sm">
            <span className="mt-0.5 inline-flex h-6 w-6 shrink-0 items-center justify-center rounded bg-primary text-primary-foreground">
              <FontAwesomeIcon icon={faCubes} className="h-3 w-3" />
            </span>
            <div className="min-w-0 flex-1 space-y-2">
              <ul className="space-y-1">
                {(steps.length ? steps : ["Connecting"]).map((s, i, arr) => (
                  <li key={i} className="flex items-center gap-2 text-muted-foreground">
                    {i === arr.length - 1 ? (
                      <FontAwesomeIcon icon={faSpinner} spin className="w-3" />
                    ) : (
                      <FontAwesomeIcon icon={faCheck} className="w-3 text-primary" />
                    )}
                    {s}
                  </li>
                ))}
              </ul>
              {live && <p className="whitespace-pre-wrap leading-relaxed">{live}</p>}
              {codeLines > 0 && (
                <p className="font-mono text-xs text-muted-foreground">Writing code… {codeLines} lines</p>
              )}
            </div>
          </div>
        )}
        <div ref={bottom} />
      </div>
      <div className="border-t p-3">
        <div className="rounded-lg border bg-card p-2">
          {image && (
            <div className="relative mb-2 inline-block">
              <img src={image} alt="Design reference" className="h-16 rounded border object-cover" />
              <button
                type="button"
                aria-label="Remove image"
                onClick={() => setImage(null)}
                className="absolute -right-2 -top-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-secondary text-xs text-foreground"
              >
                <FontAwesomeIcon icon={faXmark} />
              </button>
            </div>
          )}
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(input);
              }
            }}
            placeholder={code ? "Ask for a change" : "Describe your app"}
            className="min-h-16 resize-none border-0 bg-transparent shadow-none focus-visible:ring-0"
          />
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <input
                ref={fileInput}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  void onPickImage(e.target.files?.[0]);
                  e.target.value = "";
                }}
              />
              <Button
                variant="ghost"
                size="icon"
                aria-label="Attach a screenshot or image"
                title="Attach a screenshot to match"
                onClick={() => fileInput.current?.click()}
              >
                <FontAwesomeIcon icon={faImage} />
              </Button>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger className="h-8 w-[120px] text-xs" aria-label="Style">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STYLE_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex items-center gap-1.5">
                <Switch id="plan-first" checked={planFirst} onCheckedChange={setPlanFirst} />
                <Label htmlFor="plan-first" className="text-xs text-muted-foreground">
                  Plan first
                </Label>
              </div>
            </div>
            <Button size="icon" aria-label="Send" onClick={() => send(input)} disabled={busy || !input.trim()}>
              <FontAwesomeIcon icon={faArrowUp} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );

  const previewPane = (
    <section className="flex min-h-0 flex-1 flex-col">
      <div className="flex h-11 shrink-0 items-center justify-between gap-2 border-b px-2">
        <div className="flex gap-1">
          {(["preview", "code"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "inline-flex items-center gap-2 rounded px-3 py-1 text-sm",
                tab === t ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground",
              )}
            >
              <FontAwesomeIcon icon={t === "preview" ? faDisplay : faCode} />
              <span className="hidden sm:inline">{t === "preview" ? "Preview" : "Code"}</span>
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          <div className="hidden lg:block">
            <DeviceToggle value={device} onChange={setDevice} />
          </div>
          <Button variant="ghost" size="icon" aria-label="Reload preview" onClick={() => setFrameKey((k) => k + 1)}>
            <FontAwesomeIcon icon={faRotateRight} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Copy code"
            disabled={!code}
            onClick={() => {
              void navigator.clipboard.writeText(code);
              toast.success("Code copied");
            }}
          >
            <FontAwesomeIcon icon={faCopy} />
          </Button>
          <Link to="/preview/$id" params={{ id }} aria-label="Open full-page preview" title="Open full page">
            <Button variant="ghost" size="icon" disabled={!code} tabIndex={-1}>
              <FontAwesomeIcon icon={faExpand} />
            </Button>
          </Link>
        </div>
      </div>
      {previewError && (
        <div className="flex items-center gap-2 border-b bg-destructive/10 px-3 py-2 text-sm">
          <FontAwesomeIcon icon={faTriangleExclamation} className="text-destructive" />
          <span className="min-w-0 flex-1 truncate">Your app hit an error: {previewError}</span>
          <Button size="sm" onClick={() => fixError(previewError)} disabled={busy}>
            Fix it
          </Button>
          <Button variant="ghost" size="icon" aria-label="Dismiss" onClick={() => setPreviewError(null)}>
            <FontAwesomeIcon icon={faXmark} />
          </Button>
        </div>
      )}
      <div className="min-h-0 flex-1 bg-panel">
        {!code ? (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            {busy ? (
              <span>
                <FontAwesomeIcon icon={faSpinner} spin /> Building preview
              </span>
            ) : (
              "Your app will appear here."
            )}
          </div>
        ) : tab === "preview" ? (
          <PreviewFrame code={code} projectId={id} device={device} reloadKey={frameKey} />
        ) : (
          <pre className="h-full overflow-auto p-4 font-mono text-xs leading-relaxed text-muted-foreground">
            {code}
          </pre>
        )}
      </div>
    </section>
  );

  return (
    <div className="flex h-dvh flex-col">
      <AppHeader>
        <span className="hidden truncate text-sm text-muted-foreground sm:inline">{data.project.name}</span>
      </AppHeader>
      <div className="flex h-11 shrink-0 items-center justify-between gap-2 border-b px-2 md:justify-end">
        <div className="inline-flex rounded-md border bg-card p-0.5 md:hidden" role="tablist">
          {(["chat", "preview"] as const).map((p) => (
            <button
              key={p}
              role="tab"
              aria-selected={mobilePane === p}
              onClick={() => setMobilePane(p)}
              className={cn(
                "inline-flex items-center gap-2 rounded px-3 py-1 text-sm",
                mobilePane === p ? "bg-secondary text-foreground" : "text-muted-foreground",
              )}
            >
              <FontAwesomeIcon icon={p === "chat" ? faComments : faDisplay} />
              {p === "chat" ? "Chat" : "Preview"}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" className="gap-2" onClick={() => setVersionsOpen(true)}>
            <FontAwesomeIcon icon={faClockRotateLeft} /> <span className="hidden sm:inline">Versions</span>
          </Button>
          <Button size="sm" className="gap-2" disabled={!code} onClick={() => setPublishOpen(true)}>
            <FontAwesomeIcon icon={faGlobe} /> {data.project.is_public ? "Published" : "Publish"}
          </Button>
        </div>
      </div>
      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        <aside
          className={cn(
            "min-h-0 flex-1 flex-col bg-panel md:flex md:w-[400px] md:flex-none md:border-r",
            mobilePane === "chat" ? "flex" : "hidden",
          )}
        >
          {chatPane}
        </aside>
        <div className={cn("min-h-0 flex-1 flex-col md:flex", mobilePane === "preview" ? "flex" : "hidden")}>
          {previewPane}
        </div>
      </div>
      <VersionsSheet
        open={versionsOpen}
        onOpenChange={setVersionsOpen}
        projectId={id}
        currentCode={code}
        onRestored={() => {
          setFrameKey((k) => k + 1);
          setMobilePane("preview");
        }}
      />
      <PublishDialog
        open={publishOpen}
        onOpenChange={setPublishOpen}
        projectId={id}
        isPublic={data.project.is_public}
      />
    </div>
  );
}

function VersionsSheet({
  open,
  onOpenChange,
  projectId,
  currentCode,
  onRestored,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  projectId: string;
  currentCode: string;
  onRestored: () => void;
}) {
  const qc = useQueryClient();
  const [versions, setVersions] = useState<
    { id: string; label: string; code: string; created_at: string }[] | null
  >(null);
  const [restoring, setRestoring] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    qc.fetchQuery(versionsQuery(projectId))
      .then(setVersions)
      .catch(() => toast.error("Could not load versions"));
  }, [open, projectId, qc]);

  async function restore(v: { id: string; code: string; label: string }) {
    setRestoring(v.id);
    const { error } = await supabase
      .from("projects")
      .update({ code: v.code, updated_at: new Date().toISOString() })
      .eq("id", projectId);
    if (!error) {
      await supabase.from("project_versions").insert({
        project_id: projectId,
        code: v.code,
        label: `Restored: ${v.label}`.slice(0, 80),
      });
    }
    setRestoring(null);
    if (error) return toast.error(error.message);
    await qc.invalidateQueries({ queryKey: ["project", projectId] });
    qc.invalidateQueries({ queryKey: ["versions", projectId] });
    toast.success("Version restored");
    onRestored();
    onOpenChange(false);
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Version history</SheetTitle>
        </SheetHeader>
        <div className="mt-4 space-y-2 px-4 pb-6">
          {versions === null ? (
            <p className="text-sm text-muted-foreground">
              <FontAwesomeIcon icon={faSpinner} spin /> Loading
            </p>
          ) : versions.length === 0 ? (
            <p className="text-sm text-muted-foreground">Versions appear here after each change.</p>
          ) : (
            versions.map((v, i) => {
              const isCurrent = v.code === currentCode && versions.findIndex((x) => x.code === currentCode) === i;
              return (
                <div key={v.id} className="rounded-lg border bg-card p-3">
                  <p className="line-clamp-2 text-sm">{v.label || "Untitled change"}</p>
                  <div className="mt-2 flex items-center justify-between gap-2">
                    <span className="text-xs text-muted-foreground">
                      {new Date(v.created_at).toLocaleString()}
                    </span>
                    {isCurrent ? (
                      <span className="text-xs font-medium text-primary">Current</span>
                    ) : (
                      <Button size="sm" variant="outline" disabled={restoring !== null} onClick={() => void restore(v)}>
                        {restoring === v.id ? <FontAwesomeIcon icon={faSpinner} spin /> : "Restore"}
                      </Button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

function PublishDialog({
  open,
  onOpenChange,
  projectId,
  isPublic,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  projectId: string;
  isPublic: boolean;
}) {
  const qc = useQueryClient();
  const [saving, setSaving] = useState(false);
  const url = typeof window !== "undefined" ? `${window.location.origin}/p/${projectId}` : `/p/${projectId}`;

  async function setPublic(next: boolean) {
    setSaving(true);
    const { error } = await supabase.from("projects").update({ is_public: next }).eq("id", projectId);
    setSaving(false);
    if (error) return toast.error(error.message);
    await qc.invalidateQueries({ queryKey: ["project", projectId] });
    toast.success(next ? "Your app is live" : "Your app is no longer public");
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isPublic ? "Your app is live" : "Publish your app"}</DialogTitle>
          <DialogDescription>
            {isPublic
              ? "Anyone with this link can use your app. Changes you make show up right away."
              : "Get a shareable link anyone can open, full screen, without signing in to Orgraai."}
          </DialogDescription>
        </DialogHeader>
        {isPublic ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 rounded-md border bg-card p-2">
              <span className="min-w-0 flex-1 truncate font-mono text-xs">{url}</span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  void navigator.clipboard.writeText(url);
                  toast.success("Link copied");
                }}
              >
                Copy
              </Button>
            </div>
            <div className="flex justify-between gap-2">
              <Button variant="ghost" disabled={saving} onClick={() => void setPublic(false)}>
                Unpublish
              </Button>
              <a href={url} target="_blank" rel="noreferrer">
                <Button>Open live app</Button>
              </a>
            </div>
          </div>
        ) : (
          <Button disabled={saving} onClick={() => void setPublic(true)}>
            {saving ? <FontAwesomeIcon icon={faSpinner} spin /> : <FontAwesomeIcon icon={faGlobe} />} Publish now
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
