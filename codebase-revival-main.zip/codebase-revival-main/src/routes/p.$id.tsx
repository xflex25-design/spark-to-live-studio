import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PreviewFrame } from "@/components/PreviewFrame";

const publicAppQuery = (id: string) =>
  queryOptions({
    queryKey: ["public-app", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("projects")
        .select("id, name, code")
        .eq("id", id)
        .eq("is_public", true)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

export const Route = createFileRoute("/p/$id")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Built with Orgraai" },
      { name: "description", content: "An app built with Orgraai, the AI app builder." },
      { property: "og:title", content: "Built with Orgraai" },
      { property: "og:description", content: "An app built with Orgraai, the AI app builder." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(publicAppQuery(params.id)),
  component: PublicApp,
});

function PublicApp() {
  const { id } = Route.useParams();
  const { data } = useSuspenseQuery(publicAppQuery(id));
  if (!data || !data.code) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-3 px-6 text-center">
        <h1 className="text-xl font-semibold">This app isn't published</h1>
        <p className="text-sm text-muted-foreground">The owner may have unpublished it.</p>
        <Link to="/" className="text-sm text-primary underline">
          Build your own with Orgraai
        </Link>
      </div>
    );
  }
  return (
    <div className="h-dvh">
      <PreviewFrame code={data.code} projectId={id} />
    </div>
  );
}
